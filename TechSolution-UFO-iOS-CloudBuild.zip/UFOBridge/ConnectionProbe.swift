import Foundation
import Combine

/// Diagnostic-only WebSocket probe.
/// Does not authenticate, send control commands, or modify the fogging system.
@MainActor
final class ConnectionProbe: ObservableObject {
    enum Status: Equatable {
        case idle
        case testing
        case reachable
        case failed(String)
    }

    @Published private(set) var status: Status = .idle
    @Published private(set) var details: String = "Nessuna connessione in corso."

    private var session: URLSession?
    private var task: URLSessionWebSocketTask?
    private var attemptID = UUID()

    func test(host rawHost: String, port rawPort: String, secure: Bool) {
        disconnect()
        let host = rawHost.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !host.isEmpty, !host.contains("/"), !host.contains(":"), !host.contains(" ") else {
            status = .failed("Inserisci solo l'indirizzo IP o il nome host, senza http:// o porte.")
            return
        }
        guard let port = Int(rawPort), (1...65535).contains(port) else {
            status = .failed("La porta deve essere compresa tra 1 e 65535.")
            return
        }

        var components = URLComponents()
        components.scheme = secure ? "wss" : "ws"
        components.host = host
        components.port = port
        components.path = "/KseniaWsock"
        guard let url = components.url else {
            status = .failed("Indirizzo di connessione non valido.")
            return
        }

        let thisAttempt = UUID()
        attemptID = thisAttempt
        status = .testing
        details = "Verifica della sola apertura WebSocket, senza inviare comandi."

        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 12
        let newSession = URLSession(configuration: config)
        let newTask = newSession.webSocketTask(with: url, protocols: ["KS_WSOCK"])
        session = newSession
        task = newTask
        newTask.resume()

        // A successful pong proves the WebSocket handshake and transport worked.
        newTask.sendPing { [weak self] error in
            Task { @MainActor [weak self] in
                guard let self, self.attemptID == thisAttempt else { return }
                if let error {
                    self.status = .failed(error.localizedDescription)
                    self.details = "Connessione non verificata. Controlla Wi-Fi, IP, porta, TLS e certificato."
                } else {
                    self.status = .reachable
                    self.details = "Handshake e risposta ping riusciti. Autenticazione al nebbiogeno NON ancora eseguita."
                }
            }
        }
    }

    func disconnect() {
        attemptID = UUID()
        task?.cancel(with: .normalClosure, reason: nil)
        session?.invalidateAndCancel()
        task = nil
        session = nil
        status = .idle
        details = "Connessione chiusa."
    }
}
