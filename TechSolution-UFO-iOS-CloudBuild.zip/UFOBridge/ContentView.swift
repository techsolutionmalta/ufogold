import SwiftUI

struct ContentView: View {
    @StateObject private var probe = ConnectionProbe()
    @State private var deviceName = "Nebbiogeno UFO"
    @State private var host = ""
    @State private var port = "443"
    @State private var secure = true

    private var statusTitle: String {
        switch probe.status {
        case .idle: return "NON VERIFICATO"
        case .testing: return "CONNESSIONE IN CORSO"
        case .reachable: return "WEBSOCKET RAGGIUNGIBILE"
        case .failed: return "CONNESSIONE NON RIUSCITA"
        }
    }

    private var statusColor: Color {
        switch probe.status {
        case .idle: return .gray
        case .testing: return .orange
        case .reachable: return .green
        case .failed: return .red
        }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    header
                    deviceStatus
                    configuration
                    actions
                    diagnostics
                    Text("PROTOTIPO DIAGNOSTICO • Non effettua login e non invia comandi di attivazione, disinserimento o emissione nebbia.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .padding(.top, 8)
                }
                .padding(20)
            }
            .scrollContentBackground(.hidden)
            .background(Color(red: 0.08, green: 0.09, blue: 0.10))
            .foregroundStyle(.white)
            .navigationTitle("UFO Bridge")
            .navigationBarTitleDisplayMode(.inline)
        }
        .tint(.cyan)
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image(systemName: "shield.lefthalf.filled")
                .font(.system(size: 33))
                .foregroundStyle(.cyan)
                .frame(width: 52, height: 52)
                .background(.cyan.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
            VStack(alignment: .leading, spacing: 4) {
                Text("TechSolution · UFO Bridge")
                    .font(.headline)
                Text("Test di collegamento locale")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var deviceStatus: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Circle().fill(statusColor).frame(width: 11, height: 11)
                Text(statusTitle)
                    .font(.caption.bold())
                    .foregroundStyle(statusColor)
            }
            Text(deviceName.isEmpty ? "Nebbiogeno UFO" : deviceName)
                .font(.title2.bold())
            Text("Stato allarme: sconosciuto")
                .foregroundStyle(.secondary)
            Text("Stato fumogeno: sconosciuto")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
    }

    private var configuration: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("CONFIGURAZIONE LOCALE")
                .font(.caption.bold())
                .foregroundStyle(.secondary)
            TextField("Nome impianto", text: $deviceName)
                .textContentType(.nickname)
            Divider().overlay(Color.white.opacity(0.08))
            TextField("IP del nebbiogeno (es. 192.168.1.50)", text: $host)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(.numbersAndPunctuation)
            Divider().overlay(Color.white.opacity(0.08))
            TextField("Porta", text: $port)
                .keyboardType(.numberPad)
            Toggle("Connessione cifrata (WSS)", isOn: $secure)
        }
        .textFieldStyle(.plain)
        .padding(18)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
    }

    private var actions: some View {
        HStack(spacing: 10) {
            Button {
                probe.test(host: host, port: port, secure: secure)
            } label: {
                Label("Verifica connessione", systemImage: "network")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(probe.status == .testing)

            Button {
                probe.disconnect()
            } label: {
                Image(systemName: "xmark.circle")
                    .frame(width: 35, height: 30)
            }
            .buttonStyle(.bordered)
        }
    }

    private var diagnostics: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("DIAGNOSTICA")
                .font(.caption.bold())
                .foregroundStyle(.secondary)
            if case let .failed(message) = probe.status {
                Text(message).foregroundStyle(.red)
            }
            Text(probe.details)
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text("Percorso WebSocket: /KseniaWsock")
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
    }
}
