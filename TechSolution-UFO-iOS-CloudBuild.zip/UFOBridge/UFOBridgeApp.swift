import SwiftUI

@main
struct UFOBridgeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
