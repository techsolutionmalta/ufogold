# TechSolution UFO Bridge · iOS starter (v0.1)

Questo è un **prototipo diagnostico, non un telecomando funzionante**.
Il progetto è originale e non contiene il codice proprietario dell'APK.
Non invia comandi di inserimento, disinserimento o generazione nebbia.

## Origine delle informazioni

Analisi statica dell'APK UFO Gold 2.11.5 caricato dall'utente, senza eseguirlo.
La comunicazione locale è costruita con WebSocket `ws://` / `wss://`, percorso `/KseniaWsock` e sottoprotocollo `KS_WSOCK`. La scelta tra WS e WSS e la porta dipendono dalla configurazione dell'impianto.

## Apertura su Mac

1. Apri `UFOBridge.xcodeproj` con Xcode recente.
2. Seleziona il target `UFOBridge`, scegli il tuo **Team** in Signing & Capabilities e modifica il Bundle Identifier se richiesto.
3. Collega l'iPhone, abilita Developer Mode se necessario, selezionalo come destinazione e premi ▶.
4. Collega l'iPhone alla stessa rete locale dell'impianto, inserisci **l'IP reale** e la porta configurata, poi tocca «Verifica connessione».
5. Un messaggio «WEBSOCKET RAGGIUNGIBILE» verifica solamente la connettività. Non prova la validità del PIN, del login, del cloud o del comando di disinserimento.

## Limiti e sicurezza

- Il client usa la verifica TLS di sistema. Non disabilitare la validazione dei certificati.
- Non inserire credenziali reali nel codice sorgente.
- La connessione cloud, la gestione dei token, il PIN, la lettura stato e i comandi sono **non implementati**.
- Non verificato con un impianto fisico né compilato con Xcode in questo ambiente.
- Se il sistema è in allarme, usa prima le procedure ufficiali e il supporto dell'installatore/produttore.
