# TechSolution UFO Bridge – build iPhone SENZA Mac

Questo progetto crea un **IPA non firmato** usando GitHub Actions su un runner macOS.
L'IPA **non si installa con un semplice tap**: va firmato con un Apple Account
usando uno strumento di installazione per iPhone (es. Sideloadly su Windows).

## Cosa ottieni
- App SwiftUI diagnostica per iOS 17+.
- Prova esclusivamente una connessione WebSocket verso un indirizzo locale fornito dall'utente.
- Non autentica l'utente, non controlla l'impianto e NON disinserisce l'allarme.
- Non contiene codice proprietario, password o materiale dall'APK Android.

## Procedura da Windows
1. Crea un account su https://github.com (se non ne hai uno).
2. Crea un repository nuovo (es. `techsolution-ufo-bridge`).
   Puoi scegliere **Private**; i minuti macOS del piano GitHub potrebbero essere limitati o fatturati.
3. Carica **il contenuto** della cartella di questo progetto nella radice del repository
   (non la cartella contenitore e non il file ZIP). Devono comparire
   `UFOBridge.xcodeproj`, `UFOBridge` e `.github/workflows/build-ipa.yml`.
   Con GitHub Desktop è semplice: aggiungi i file nella cartella del repository,
   fai Commit e Push. In alternativa carica i file dal browser mantenendo i percorsi.
4. Apri la scheda **Actions** del repository. Se richiesto abilita i workflow.
5. Apri **Compila UFO Bridge per iPhone (IPA non firmata)** e premi
   **Run workflow** sul branch `main`. In alternativa la compilazione parte al push su main.
6. Al termine, apri l'esecuzione con spunta verde; in **Artifacts** scarica
   `TechSolution-UFOBridge-unsigned-IPA`. Estrai il suo ZIP.
7. Trovi `TechSolution-UFOBridge-unsigned.ipa`.
8. Su Windows, uno strumento come Sideloadly (https://sideloadly.io/) può
   firmare l'IPA con il TUO Apple Account e installarla sul TUO iPhone via USB.
   Segui i prerequisiti e le istruzioni ufficiali del programma scelto.

Non pubblicare password, PIN, certificati o identificativi sensibili su GitHub.
Non caricare l'APK originale nel repository pubblico.

## Limitazioni importanti
- Nessuna build reale è stata eseguita da questo ambiente: il workflow sarà
  la prima prova di compilazione con Xcode.
- La firma effettuata con un Apple Account gratuito dura di regola 7 giorni.
- GitHub Actions produce solo l'IPA non firmata; non acquisisce credenziali Apple.
- La verifica di connessione non conferma la compatibilità con l'impianto.
- Per disinserire un allarme attivo, seguire le procedure originali del
  produttore o richiedere intervento dell'installatore.
