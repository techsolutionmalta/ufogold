# UFO Bridge 1.0.2 – test inequivocabile della build

Questa versione ha il **nome icona "UFO Bridge 102"**, un banner giallo "NUOVA VERSIONE • BUILD 12" sulla pagina Impianto, e mostra **1.0.2 (12)** in Diagnosi.

L’icona UFO Gold è nel catalogo `UFOBridge/Assets.xcassets/AppIcon.appiconset`.

**Non è un controller di sicurezza collaudato:** cloud, login, lettura delle partizioni e i comandi ricostruiti devono essere verificati su una centralina autorizzata. Non sostituire l’app originale o il telecomando ufficiale.

La build è volutamente bloccante: usa solo `UFOBridge-1.0.2-VERIFICA.zip`, verifica versione/nome sorgenti e produce una prova di versione insieme all’IPA. Non compilare vecchi ZIP.

### Installazione
1. Carica `UFOBridge-1.0.2-VERIFICA.zip` nella cartella principale del repository GitHub.
2. Sostituisci tutto il contenuto di `.github/workflows/blank.yml` con il codice del workflow `build-ipa.yml` qui incluso (oppure crea `build-ipa.yml` senza lasciare vecchi workflow ambigui).
3. Esegui la nuova azione `UFO Bridge 1.0.2 - BUILD12 VERIFICATA`.
4. Scarica solo l'artifact `UFOBridge-V102-BUILD12-VERIFICATA`. Contiene l'IPA e il rapporto `BUILD-VERIFICATA.txt`.
5. Firma e installa solo quella IPA. Non eliminare l'app esistente; preserva il bundle ID originario e l'account Apple. In caso di richiesta di disinstallazione, fermati.

Verifica sull'iPhone: icona UFO e nome `UFO Bridge 102`, banner giallo, scheda `Configura` con Cloud Ksenia e Trova IP. Non equivale a certificare il controllo dell'allarme.
