import Foundation

func require(_ value: @autoclosure () -> Bool, _ message: String) {
    guard value() else { fputs("ERRORE: \(message)\n", stderr); exit(1) }
}

require(KseniaProtocol.crc16("123456789".utf8) == "0xa69d", "CRC16 originale UFO Gold")

let packet = try KseniaProtocol.packet(
    sender: "D0E1F2A3B4C5-l4", receiver: "1234567890123456", command: "LOGIN",
    kind: "USER", payload: ["PIN": "000000"], id: 17)
let data = packet.data(using: .utf8)!
let object = try JSONSerialization.jsonObject(with: data) as! [String: Any]
let payload = object["PAYLOAD"] as! [String: Any]
require(object["CMD"] as? String == "LOGIN", "comando serializzato")
require(object["PAYLOAD_TYPE"] as? String == "USER", "payload type")
require(payload["PIN"] as? String == "000000", "test payload")
require((object["CRC_16"] as? String)?.hasPrefix("0x") == true, "campo CRC16")
print("OK: CRC16 e struttura JSON testati (nessun accesso a dispositivi)")
