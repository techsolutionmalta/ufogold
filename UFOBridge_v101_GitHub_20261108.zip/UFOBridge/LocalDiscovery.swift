import Foundation
import Combine
import Network
import Darwin

/// Ricerca sul Wi-Fi dell'utente: Bonjour passivo e, su richiesta, TCP/443
/// entro la sola subnet /24. Non invia PIN, non fa tentativi di login.
@MainActor
final class LocalDiscovery: ObservableObject {
    @Published private(set) var isSearching = false
    @Published private(set) var suggestions: [String] = []
    @Published private(set) var message = "Seleziona la ricerca passiva o quella IP locale."
    private var browsers: [NWBrowser] = []
    private var scanID = UUID()

    func search() {
        stop()
        isSearching = true
        suggestions = []
        message = "Cerco dispositivi annunciati tramite Bonjour…"
        for type in ["_https._tcp", "_http._tcp"] {
            let browser = NWBrowser(for: .bonjour(type: type, domain: nil), using: .tcp)
            browser.stateUpdateHandler = { [weak self] state in
                if case .failed(let error) = state {
                    Task { @MainActor [weak self] in self?.message = "Bonjour: \(error.localizedDescription)" }
                }
            }
            browser.browseResultsChangedHandler = { [weak self] results, _ in
                let matching = results.compactMap { result -> String? in
                    guard case let .service(name, _, _, _) = result.endpoint else { return nil }
                    let lower = name.lowercased()
                    guard ["ksenia", "ks-board", "lares", "ufo", "fog"].contains(where: { lower.contains($0) }) else { return nil }
                    return name
                }
                Task { @MainActor [weak self] in
                    guard let self else { return }
                    self.suggestions = Array(Set(self.suggestions + matching)).sorted()
                    if !matching.isEmpty { self.message = "Trovati nomi di servizi. Verifica l'IP nel router." }
                }
            }
            browser.start(queue: DispatchQueue.global(qos: .utility))
            browsers.append(browser)
        }
    }

    func scanLocalSubnet() {
        stop()
        guard let ipv4 = Self.wifiAddress() else {
            message = "Impossibile leggere l'IP del Wi-Fi. Collega l'iPhone alla rete del nebbiogeno."
            return
        }
        let parts = ipv4.split(separator: ".")
        guard parts.count == 4, let first = Int(parts[0]), let second = Int(parts[1]),
              first == 10 || (first == 192 && second == 168) || (first == 172 && (16...31).contains(second)) else {
            message = "Scansione consentita soltanto su una rete locale privata."
            return
        }
        isSearching = true
        suggestions = []
        let id = UUID(); scanID = id
        let prefix = parts.prefix(3).joined(separator: ".")
        message = "Rete \(prefix).0/24: verifica dei dispositivi con TCP/443 aperto."
        Task { [weak self] in
            guard let self else { return }
            // Gruppi da 16 per non saturare la rete.
            for start in stride(from: 1, through: 254, by: 16) {
                guard self.scanID == id else { return }
                let ips = (start...min(start + 15, 254)).map { "\(prefix).\($0)" }
                let successes = await withTaskGroup(of: String?.self, returning: [String].self) { group in
                    for ip in ips where ip != ipv4 {
                        group.addTask { await Self.tcpPort443(ip) ? ip : nil }
                    }
                    var found: [String] = []
                    for await result in group { if let result { found.append(result) } }
                    return found
                }
                guard self.scanID == id else { return }
                self.suggestions = Array(Set(self.suggestions + successes)).sorted()
                self.message = "Scansione \(min(start + 15, 254))/254 · \(self.suggestions.count) IP possibili. Verificare sempre dalla centralina."
            }
            if self.scanID == id {
                self.isSearching = false
                if self.suggestions.isEmpty { self.message = "Nessuna porta 443 aperta rilevata: inserisci l'IP dal router." }
                else { self.message = "Scansione terminata. Gli IP elencati non sono ancora verificati come Ksenia." }
            }
        }
    }

    private nonisolated static func wifiAddress() -> String? {
        var addresses: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&addresses) == 0, let addresses else { return nil }
        defer { freeifaddrs(addresses) }
        var cursor: UnsafeMutablePointer<ifaddrs>? = addresses
        while let node = cursor {
            defer { cursor = node.pointee.ifa_next }
            guard let address = node.pointee.ifa_addr,
                  address.pointee.sa_family == UInt8(AF_INET),
                  String(cString: node.pointee.ifa_name) == "en0" else { continue }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            if getnameinfo(address, socklen_t(address.pointee.sa_len), &host,
                           socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 {
                return String(cString: host)
            }
        }
        return nil
    }

    private nonisolated static func tcpPort443(_ host: String) async -> Bool {
        await withCheckedContinuation { continuation in
            let connection = NWConnection(host: NWEndpoint.Host(host),
                                          port: NWEndpoint.Port(rawValue: 443)!, using: .tcp)
            let lock = NSLock()
            var completed = false
            func finish(_ result: Bool) {
                lock.lock()
                let shouldFinish = !completed
                completed = true
                lock.unlock()
                if shouldFinish {
                    connection.cancel()
                    continuation.resume(returning: result)
                }
            }
            connection.stateUpdateHandler = { state in
                switch state {
                case .ready: finish(true)
                case .failed, .cancelled: finish(false)
                default: break
                }
            }
            connection.start(queue: DispatchQueue.global(qos: .utility))
            DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 0.65) {
                finish(false)
            }
        }
    }

    func stop() {
        scanID = UUID()
        browsers.forEach { $0.cancel() }
        browsers.removeAll()
        isSearching = false
    }
}
