import SwiftUI

private struct PartitionAction: Identifiable {
    var id: String { partitionID + (disarm ? "-disarm" : "-arm") }
    let partitionID: String
    let partitionName: String
    let disarm: Bool
}

struct ContentView: View {
    @StateObject private var bridge = KseniaSession()
    @StateObject private var discovery = LocalDiscovery()
    @Environment(\.scenePhase) private var scenePhase

    @AppStorage("ufoBridgeName") private var deviceName = "Nebbiogeno UFO"
    @AppStorage("ufoBridgeHost") private var host = ""
    @AppStorage("ufoBridgePort") private var port = "443"
    @AppStorage("ufoBridgeTLS") private var secure = true
    @AppStorage("ufoBridgeSerial") private var serialNumber = ""
    @AppStorage("ufoBridgeMode") private var mode = 0

    @State private var pin = ""
    @State private var revealPIN = false
    @State private var action: PartitionAction?
    @State private var confirmPin = ""
    @State private var confirmationNotice = ""
    @State private var tab = 0
    @State private var showSecurityInfo = false

    private var phaseText: String {
        switch bridge.phase {
        case .idle: return "NON CONNESSO"
        case .connecting: return "COLLEGAMENTO…"
        case .connected: return "COLLEGATO · NON AUTENTICATO"
        case .authenticating: return "VERIFICA PIN…"
        case .authenticated: return "AUTENTICATO"
        case .error: return "ERRORE DI COLLEGAMENTO"
        }
    }
    private var phaseColor: Color {
        switch bridge.phase {
        case .authenticated: return .green
        case .connecting, .authenticating, .connected: return .orange
        case .error: return .red
        case .idle: return .gray
        }
    }

    var body: some View {
        TabView(selection: $tab) {
            NavigationStack { homeScreen.navigationTitle("UFO Gold · Bridge") }
                .tabItem { Label("Impianto", systemImage: "shield.lefthalf.filled") }.tag(0)
            NavigationStack { settingsScreen.navigationTitle("Configurazione") }
                .tabItem { Label("Configura", systemImage: "gearshape.2") }.tag(1)
            NavigationStack { diagnosticsScreen.navigationTitle("Diagnostica") }
                .tabItem { Label("Diagnosi", systemImage: "waveform.path.ecg") }.tag(2)
        }
        .tint(.cyan)
        .preferredColorScheme(.dark)
        .onChange(of: mode) { _, _ in bridge.disconnect() }
        .onChange(of: bridge.phase) { _, newValue in
            if case .authenticated = newValue { pin = "" }
        }
        .onChange(of: scenePhase) { _, state in
            if state != .active {
                bridge.disconnect()
                pin = ""
                confirmPin = ""
                action = nil
            }
        }
        .sheet(item: $action, onDismiss: {
            confirmPin = ""
            confirmationNotice = ""
        }) { selected in
            NavigationStack {
                VStack(alignment: .leading, spacing: 18) {
                    Label("Conferma di sicurezza", systemImage: "lock.shield")
                        .font(.headline)
                    Text("Partizione: \(selected.partitionName)")
                    Text(selected.disarm ? "Richiesta: disinserimento" : "Richiesta: inserimento ritardato")
                        .font(.subheadline).foregroundStyle(.orange)
                    SecureField("Reinserisci il PIN autorizzato", text: $confirmPin)
                        .textContentType(.oneTimeCode)
                        .keyboardType(.numberPad)
                        .padding(12)
                        .background(Color.secondary.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
                    Text("Il comando è disponibile solo dopo login locale e lettura valida dello stato. Nessuna emissione nebbia. Verifica fisicamente l'impianto.")
                        .font(.footnote).foregroundStyle(.secondary)
                    if !confirmationNotice.isEmpty {
                        Text(confirmationNotice).font(.caption).foregroundStyle(.red)
                    }
                    Button(role: .destructive) {
                        guard !confirmPin.isEmpty else {
                            confirmationNotice = "Inserisci nuovamente il PIN."
                            return
                        }
                        bridge.changePartition(id: selected.partitionID, disarm: selected.disarm,
                                               confirmedPin: confirmPin)
                        confirmPin = ""
                        action = nil
                    } label: {
                        Text("Conferma \(selected.disarm ? "disinserimento" : "inserimento")")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(!bridge.canCommandPartitions)
                    Spacer()
                }
                .padding(20)
                .navigationTitle("Autorizzazione")
                .toolbar { ToolbarItem(placement: .cancellationAction) {
                    Button("Annulla") { action = nil }
                }}
            }
            .presentationDetents([.medium, .large])
        }
    }

    private var homeScreen: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                brand
                section {
                    HStack(spacing: 9) {
                        Circle().fill(phaseColor).frame(width: 10, height: 10)
                        Text(phaseText).font(.caption.weight(.semibold)).foregroundStyle(phaseColor)
                    }
                    Text(deviceName).font(.title2.bold())
                    Text(bridge.isLoggedIn ? bridge.generalStatus : "Nessuno stato allarme verificato")
                        .foregroundStyle(.secondary)
                    if let last = bridge.lastUpdate {
                        Text("Ultima lettura: \(last.formatted(date: .omitted, time: .shortened))")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    if let count = bridge.zonesCount {
                        Label("Zone comunicate dalla centrale: \(count)", systemImage: "square.grid.2x2")
                            .font(.subheadline)
                    }
                }
                section {
                    Label("Accesso autorizzato", systemImage: "lock.shield").font(.headline)
                    Text("Inserisci seriale e PIN utente nella scheda Configura. Il PIN resta soltanto nella memoria della sessione e non viene salvato nell'app.")
                        .font(.caption).foregroundStyle(.secondary)
                    if revealPIN { TextField("PIN utente", text: $pin) }
                    else { SecureField("PIN utente", text: $pin) }
                    Toggle("Mostra PIN", isOn: $revealPIN).font(.caption)
                    Button {
                        if bridge.isLoggedIn { bridge.refresh() }
                        else {
                            bridge.start(host: host, port: port, tls: secure,
                                         serial: serialNumber, pin: pin, remote: mode == 1)
                        }
                    } label: {
                        Label(bridge.isLoggedIn ? "Aggiorna dati" : "Collega e accedi",
                              systemImage: bridge.isLoggedIn ? "arrow.clockwise" : "network")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(bridge.isBusy)
                    if bridge.phase != .idle {
                        Button("Disconnetti", role: .cancel) { bridge.disconnect(); pin = "" }
                            .buttonStyle(.bordered)
                    }
                    if case let .error(message) = bridge.phase {
                        Text(message).font(.caption).foregroundStyle(.red)
                    }
                }
                section {
                    HStack {
                        Label("Partizioni", systemImage: "square.stack.3d.up").font(.headline)
                        Spacer()
                        if !bridge.partitions.isEmpty { Text("\(bridge.partitions.count)").foregroundStyle(.secondary) }
                    }
                    if bridge.partitions.isEmpty {
                        Text("Le partizioni appariranno dopo un login e una risposta valida dalla centrale.")
                            .font(.subheadline).foregroundStyle(.secondary)
                    } else {
                        ForEach(bridge.partitions) { item in
                            VStack(alignment: .leading, spacing: 7) {
                                Text(item.label).font(.headline)
                                if !item.detail.isEmpty { Text(item.detail).font(.caption).foregroundStyle(.secondary) }
                                HStack {
                                    Button("Inserisci") {
                                        action = PartitionAction(partitionID: item.id, partitionName: item.label, disarm: false)
                                    }.buttonStyle(.bordered)
                                    Button("Disinserisci", role: .destructive) {
                                        action = PartitionAction(partitionID: item.id, partitionName: item.label, disarm: true)
                                    }.buttonStyle(.bordered)
                                }.disabled(!bridge.canCommandPartitions || !item.verifiedState)
                            }
                            Divider().overlay(Color.white.opacity(0.1))
                        }
                    }
                    Text("I comandi alle partizioni sono abilitati solo dopo login locale; non è disponibile alcun comando di emissione nebbia.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }.padding(18)
        }.background(Color(red: 0.075, green: 0.09, blue: 0.11))
    }

    private var brand: some View {
        HStack(spacing: 13) {
            Image("AppLogo").resizable().scaledToFit().frame(width: 62, height: 62)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            VStack(alignment: .leading, spacing: 4) {
                Text("TechSolution · UFO Bridge").font(.headline)
                Text("Release 1.0.1 RC · iOS · Ksenia lares").font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    private var settingsScreen: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                section {
                    Text("IMPIANTO").font(.caption.bold()).foregroundStyle(.secondary)
                    TextField("Nome impianto", text: $deviceName)
                    fieldDivider
                    TextField("Seriale centrale (16 cifre)", text: $serialNumber)
                        .keyboardType(.numberPad).textInputAutocapitalization(.never)
                    Text("Ricavalo dall'etichetta o dall'app originale. Non inviarlo in repository pubblici.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                section {
                    Text("MODALITÀ DI CONNESSIONE").font(.caption.bold()).foregroundStyle(.secondary)
                    Picker("Modalità", selection: $mode) {
                        Text("Rete locale").tag(0)
                        Text("Cloud Ksenia").tag(1)
                    }.pickerStyle(.segmented)
                    if mode == 0 {
                        TextField("IP centralina (es. 192.168.1.50)", text: $host)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                        fieldDivider
                        TextField("Porta (di norma 443)", text: $port).keyboardType(.numberPad)
                        Toggle("TLS sicuro (WSS)", isOn: $secure)
                        if !secure { Text("Il login richiede WSS attivo.").font(.caption).foregroundStyle(.orange) }
                        Text("Non disattivare TLS se la centrale usa un certificato problematico: confronta prima la configurazione dell'impianto.")
                            .font(.caption2).foregroundStyle(.secondary)
                        HStack {
                            Button {
                                if discovery.isSearching { discovery.stop() } else { discovery.search() }
                            } label: {
                                Label("Bonjour", systemImage: "wifi")
                            }.buttonStyle(.bordered)
                            Button {
                                if discovery.isSearching { discovery.stop() } else { discovery.scanLocalSubnet() }
                            } label: {
                                Label(discovery.isSearching ? "Ferma" : "Trova IP", systemImage: "network")
                            }.buttonStyle(.bordered)
                        }
                        Text(discovery.message).font(.caption2).foregroundStyle(.secondary)
                        ForEach(discovery.suggestions, id: \.self) { suggestion in
                            Button {
                                if suggestion.split(separator: ".").count == 4 {
                                    host = suggestion
                                    discovery.stop()
                                }
                            } label: {
                                Label(suggestion, systemImage: "network.badge.shield.half.filled")
                            }.font(.caption).buttonStyle(.bordered)
                        }
                        if let address = URL(string: "https://" + host + ":" + port), !host.isEmpty {
                            Link("Apri interfaccia web locale", destination: address)
                        }
                    } else {
                        Label("Relay: api.kseniasecureweb.com:443", systemImage: "cloud")
                            .font(.subheadline)
                        Text("Connessione remota sperimentale: il relay potrebbe richiedere l’autenticazione SecureWeb del produttore oltre al PIN. I comandi sulle partizioni non sono disponibili da remoto.")
                            .font(.caption).foregroundStyle(.secondary)
                        Link(destination: URL(string: "https://www.kseniasecureweb.com/")!) {
                            Label("Apri il portale ufficiale Ksenia", systemImage: "arrow.up.right.square")
                        }
                    }
                }
                section {
                    Label("Installazione e rinnovo", systemImage: "iphone.and.arrow.forward").font(.headline)
                    Text("Con Apple Account gratuito, l'app scade dopo 7 giorni. SideStore permette di rinnovarla dall'iPhone, dopo la prima installazione tramite computer. UFO Bridge non modifica né rinnova i profili Apple autonomamente.")
                        .font(.caption).foregroundStyle(.secondary)
                    Link("Guida ufficiale SideStore", destination: URL(string: "https://docs.sidestore.io/docs/installation/install")!)
                        .font(.subheadline)
                    Text("La versione Cloud resta sperimentale finché non viene eseguito il test sulla centrale reale.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                section {
                    Text("SICUREZZA").font(.caption.bold()).foregroundStyle(.secondary)
                    Label("Il PIN non viene archiviato", systemImage: "key.horizontal")
                    Label("Verifica TLS standard attiva", systemImage: "lock")
                    Label("Nessun comando di emissione nebbia", systemImage: "aqi.medium")
                    Text("Una connessione riuscita non equivale a certificare che l'impianto sia disinserito.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }.padding(18)
        }.background(Color(red: 0.075, green: 0.09, blue: 0.11))
    }

    private var diagnosticsScreen: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                section {
                    Text("DIAGNOSTICA DELLA SESSIONE").font(.caption.bold()).foregroundStyle(.secondary)
                    Text(phaseText).foregroundStyle(phaseColor).font(.headline)
                    Text(bridge.diagnostic).font(.subheadline)
                    Text("Trasporto: " + (mode == 0 ? "locale" : "cloud") + " · KS_WSOCK")
                        .font(.caption.monospaced()).foregroundStyle(.secondary)
                    Text("Build: 1.0.1 (11) · Protocollo sperimentale")
                        .font(.caption.monospaced()).foregroundStyle(.secondary)
                    ShareLink(item: bridge.safeDiagnosticSummary(mode: mode == 0 ? "locale" : "cloud")) {
                        Label("Condividi riepilogo senza credenziali", systemImage: "square.and.arrow.up")
                    }.font(.subheadline)
                    if let last = bridge.lastUpdate {
                        Text("Ultima risposta: \(last.formatted(date: .abbreviated, time: .standard))")
                            .font(.caption)
                    }
                }
                section {
                    Label("Test in presenza del proprietario", systemImage: "checkmark.shield").font(.headline)
                    Text("""
                         1. Accerta IP e numero seriale dall'impianto.
                         2. Collega il telefono allo stesso Wi-Fi.
                         3. Inserisci il PIN utente autorizzato.
                         4. Esegui login e verifica la lettura delle partizioni.
                         5. Ripeti il login in modalità cloud usando la rete cellulare.
                         6. Controlla fisicamente lo stato prima di usare qualunque comando.
                         """)
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                section {
                    Text("LIMITI DELLA RELEASE 1.0.1 RC").font(.headline)
                    Text("Protocollo ricostruito dall'APK Android e dalla documentazione disponibile. Non ancora testato sul nebbiogeno specifico. Le funzioni radio, le notifiche push e i comandi di erogazione nebbia non sono implementati. Un certificato locale scaduto può impedire il collegamento sicuro.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
            }.padding(18)
        }.background(Color(red: 0.075, green: 0.09, blue: 0.11))
    }

    private var fieldDivider: some View { Divider().overlay(Color.white.opacity(0.12)) }

    private func section<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 13, content: content)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(17)
            .background(Color.white.opacity(0.075), in: RoundedRectangle(cornerRadius: 16))
    }
}
