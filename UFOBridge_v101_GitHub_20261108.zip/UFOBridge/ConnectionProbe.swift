import Foundation
import Combine

/// Trasporto diagnostico, SENZA autenticazione e SENZA comandi alla centralina.
/// Il supporto cloud verifica solo l'handshake WSS tramite SecureWeb.
@MainActor
final class ConnectionProbe: NSObject, ObservableObject, URLSessionWebSocketDelegate {
    enum Status: Equatable {
        case idle
        case testing
        case reachable
        case failed(String)
    }

    @Published private(set) var status: Status = .idle
    @Published private(set) var details = "Nessuna connessione in corso."

    private var session: URLSession?
    private var socket: URLSessionWebSocketTask?
    private var attemptID = UUID()

    func testLocal(host rawHost: String, port rawPort: String, secure: Bool) {
        disconnect()
        let host = rawHost.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !host.isEmpty, !host.contains("/"), !host.contains(":"), !host.contains(" ") else {
            status = .failed("Inserisci l'IP della centrale senza http:// o porte.")
            return
        }
        guard let port = Int(rawPort), (1...65535).contains(port) else {
            status = .failed("La porta deve essere compresa tra 1 e 65535.")
            return
        }
        var url = URLComponents()
        url.scheme = secure ? "wss" : "ws"
        url.host = host
        url.port = port
        url.path = "/KseniaWsock"
        guard let endpoint = url.url else {
            status = .failed("Indirizzo locale non valido.")
            return
        }
        connect(to: endpoint, location: "Rete locale")
    }

    func testCloud(serial rawSerial: String) {
        disconnect()
        let serial = rawSerial.trimmingCharacters(in: .whitespacesAndNewlines)
        guard serial.count == 16, serial.allSatisfy({ "0123456789".contains($0) }) else {
            status = .failed("Inserisci il seriale di 16 cifre della centralina (non il codice PIN).")
            return
        }

        // L'app Android UFO Gold usa il seriale e un ID mittente nel collegamento WSS.
        // NON costituiscono credenziali: il sistema richiede un login autorizzato separato.
        let key = "ufoBridgeSenderV02"
        let sender: String
        if let saved = UserDefaults.standard.string(forKey: key), !saved.isEmpty {
            sender = saved
        } else {
            sender = UUID().uuidString.lowercased() + "-l4"
            UserDefaults.standard.set(sender, forKey: key)
        }
        var url = URLComponents()
        url.scheme = "wss"
        url.host = "api.kseniasecureweb.com"
        url.port = 443
        url.path = "/KseniaWsock"
        url.queryItems = [
            URLQueryItem(name: "serialNumber", value: serial),
            URLQueryItem(name: "sender", value: sender)
        ]
        guard let endpoint = url.url else {
            status = .failed("Indirizzo del cloud non valido.")
            return
        }
        connect(to: endpoint, location: "Cloud Ksenia SecureWeb")
    }

    private func connect(to endpoint: URL, location: String) {
        let id = UUID()
        attemptID = id
        status = .testing
        details = "\(location): apertura WebSocket cifrato, senza inviare PIN o comandi."
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 12
        config.timeoutIntervalForResource = 15
        let newSession = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        let newSocket = newSession.webSocketTask(with: endpoint, protocols: ["KS_WSOCK"])
        session = newSession
        socket = newSocket
        newSocket.resume()
        Task { [weak self] in
            try? await Task.sleep(nanoseconds: 12_000_000_000)
            guard let self, self.attemptID == id, case .testing = self.status else { return }
            self.status = .failed("Timeout: nessuna conferma WebSocket entro 12 secondi.")
            self.details = "Controlla rete, seriale/IP, disponibilità del cloud e certificato TLS."
            self.closeTransport()
        }
    }

    nonisolated func urlSession(_ session: URLSession, webSocketTask: URLSessionWebSocketTask,
                               didOpenWithProtocol protocol: String?) {
        Task { @MainActor [weak self] in
            guard let self, self.socket === webSocketTask else { return }
            self.status = .reachable
            self.details = "Handshake WebSocket riuscito (\(`protocol` ?? "nessun sottoprotocollo")). Non è stato effettuato alcun login e lo stato dell'impianto rimane sconosciuto."
            self.closeTransport()
        }
    }

    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask,
                               didCompleteWithError error: Error?) {
        Task { @MainActor [weak self] in
            guard let self, self.socket === task, case .testing = self.status else { return }
            let message = error?.localizedDescription ?? "Connessione chiusa prima del completamento."
            self.status = .failed(message)
            self.details = "Connessione non verificata. I controlli TLS restano attivi."
            self.closeTransport()
        }
    }

    private func closeTransport() {
        socket?.cancel(with: .normalClosure, reason: nil)
        session?.invalidateAndCancel()
        socket = nil
        session = nil
    }

    func disconnect() {
        attemptID = UUID()
        closeTransport()
        status = .idle
        details = "Connessione chiusa."
    }
}
