import Foundation

/// Pacchetti compatibili con la sintassi pubblicata nell'SDK lares 4.0.
/// Funzioni testabili offline; non includono né espongono PIN o segreti.
enum KseniaProtocol {
    static func packet(sender: String, receiver: String, command: String,
                       kind: String, payload: [String: Any], id: Int) throws -> String {
        // L'SDK richiede la CRC16 del prefisso serializzato fino alla chiave CRC_16 inclusa.
        let data = try JSONSerialization.data(withJSONObject: payload, options: [.fragmentsAllowed, .sortedKeys])
        guard let payloadString = String(data: data, encoding: .utf8) else { throw NSError(domain: "UFO", code: 1) }
        let timestamp = Int(Date().timeIntervalSince1970)
        func quote(_ s: String) -> String {
            let bytes = try? JSONSerialization.data(withJSONObject: [s], options: [.fragmentsAllowed])
            guard let bytes, let json = String(data: bytes, encoding: .utf8) else { return "\"\"" }
            return String(json.dropFirst().dropLast())
        }
        let raw = """
        {
                    "SENDER":\(quote(sender)),
                    "RECEIVER":\(quote(receiver)),
                    "CMD":\(quote(command)),
                    "ID":\(quote(String(id))),
                    "PAYLOAD_TYPE":\(quote(kind)),
                    "PAYLOAD":\(payloadString),
                    "TIMESTAMP":\(quote(String(timestamp))),
                    "CRC_16":""
                }
        """
        guard let range = raw.range(of: "\"CRC_16\"") else { throw NSError(domain: "UFO", code: 2) }
        let prefix = String(raw[..<range.upperBound])
        let crc = crc16(prefix.utf8)
        return raw.replacingOccurrences(of: "\"CRC_16\":\"\"", with: "\"CRC_16\":\"\(crc)\"")
    }

    static func crc16<S: Sequence>(_ data: S) -> String where S.Element == UInt8 {
        var crc: UInt16 = 0xffff
        for byte in data {
            for bit in stride(from: 7, through: 0, by: -1) {
                let carry = (crc & 0x8000) != 0
                crc = crc &<< 1
                if byte & (UInt8(1) << UInt8(bit)) != 0 { crc = crc &+ 1 }
                if carry { crc ^= 0x1021 }
            }
        }
        return String(format: "0x%04x", crc)
    }
}
