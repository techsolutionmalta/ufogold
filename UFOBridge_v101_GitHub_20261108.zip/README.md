# TechSolution UFO Bridge 1.0.1 RC

App iOS sperimentale per una centrale UFO/Ksenia **di cui si è proprietari o utenti autorizzati**.

**Stato:** codice sorgente verificato staticamente. Test offline CRC/JSON superati. La compilazione Xcode e il funzionamento su centralina reale restano da verificare.

Questa release non sostituisce il telecomando ufficiale né un impianto di sicurezza funzionante. Non usare il dispositivo se la centralina non comunica, non disattivare le protezioni TLS e non inviare PIN o seriali completi su GitHub.

Apri `GUIDA-INSTALLAZIONE-E-COLLAUDO.md` per le istruzioni pratiche e `NOTE-TECNICHE.md` per i limiti.
