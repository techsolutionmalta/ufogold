# Note tecniche — UFO Bridge 1.0.1 RC

## Contenuti e controlli

- App iOS 17+ nativa SwiftUI, `CFBundleIdentifier = com.techsolution.ufobridge` (uguale alla 1.0), `CFBundleShortVersionString=1.0.1`, build 11.
- Icona UFO Gold presente nell'APK fornito dall'utente; catalogo AppIcon 1024×1024 RGB senza canale alpha.
- Schede Impianto / Configura / Diagnosi; seriale e indirizzo locale in impostazioni del telefono, non nel repository.
- Ricerca Bonjour manuale e scansione IP candidati TCP 443 sulla rete Wi-Fi privata /24 **attivata manualmente**. Nessun auto-pairing garantito.
- Trasporto WebSocket con sottoprotocollo KS_WSOCK; richiede TLS verificato dal sistema per inviare il PIN; nessun bypass di certificati scaduti o invalidi.
- Tentativo di collegamento Cloud Ksenia SecureWeb **sperimentale** con seriale. La connessione alla porta del relay non certifica che l'autenticazione/autorizzazione sia riuscita; potrebbe essere necessario il flusso OAuth ufficiale.
- Login PIN originale, READ di partizioni/zone/stato, interfaccia diagnostica, operazioni partizioni **solo locali** dopo sessione validata, reinserimento del PIN, verifica recentissima dello stato (entro un minuto).
- PIN non salvato su disco. Sessione chiusa quando l'app lascia il primo piano. Nessun comando di emissione nebbia, bypass sensori, pairing telecomandi o aggiornamento firmware.
- Riepilogo condivisibile privo di PIN, seriale e IP.

## Limiti confermati

- Non è stato disponibile un dispositivo reale. Nessuna connessione reale, login o comando su centralina è stato eseguito.
- Non è stato disponibile Xcode: si è svolto controllo sintattico Swift via Linux e test offline del pacchetto CRC/JSON. La **compilazione iOS completa** deve riuscire in GitHub Actions.
- La replica non riproduce la registrazione del cloud del produttore (Cognito), né le notifiche push o le funzioni proprietarie del nebbiogeno.
- La compatibilità è da verificare con *esatto modello e firmware* dell'impianto. Non usarla come sostituzione certificata di un sistema di sicurezza reale.
- La firma e la distribuzione dell'IPA non sono parte della logica di UFO Bridge e non possono eliminare i limiti dell'account Apple gratuito.

## Test offline ripetibili

```sh
./Tests/run-offline-tests.sh
swiftc -frontend -parse UFOBridge/*.swift
```

Il test CRC segue **l'algoritmo implementato nel bundle UFO Gold** (un CRC16 a input bit-oriented), non assume un generico CRC-CCITT-FALSE. Verifica la stringa `123456789 -> 0xa69d` e l'impacchettamento JSON. Il test non interagisce con alcuna rete.

## Tutela sicurezza

Il possesso dell'APK non equivale all'autorizzazione di usare un impianto altrui. Richiedere consenso del proprietario e utilizzare il PIN utente a lui assegnato. Non inviare su GitHub segreti o dati di accesso. L'icona UFO è un marchio di terzi e per pubblicarla sull'App Store potrebbe essere necessaria autorizzazione del titolare.
