# Installare UFO Bridge 1.0.1 RC e far rinnovare l'app dall'iPhone

## A. Compilare dal repository GitHub esistente

Repository: https://github.com/techsolutionmalta/ufogold

Il workflow `main/.github/workflows/blank.yml` attuale estrae **esattamente** `TechSolution-UFO-iOS-CloudBuild.zip` dalla radice.

1. In **Code**, clicca su `TechSolution-UFO-iOS-CloudBuild.zip` e usa `...` → **Delete file**, poi **Commit changes**.
2. Da **Code** → **Add file** → **Upload files**, carica la nuova copia **omonima** contenuta nei download e fai **Commit changes**. Non estrarre lo ZIP su GitHub: il workflow lo estrae.
3. **Actions** → **Compila UFO Bridge per iPhone** → **Run workflow**, branch `main`. Non scegliere *Re-run jobs* della vecchia esecuzione.
4. Apri la nuova esecuzione verde → **Artifacts** → `TechSolution-UFO-iPhone`. Scarica l'archivio ed estrai `UFOBridge.ipa`.
5. Prima di sostituire l'app precedente, esegui un backup dell'iPhone. Per aggiornare senza perdita dei dati va mantenuto il Bundle ID e va usato un firmatario compatibile; se l'installatore richiede di cancellare l'app, interrompi.
6. Alla prima apertura, in **Impianto** e **Diagnosi** deve comparire chiaramente **1.0.1 RC / build 11**. Se appare ancora 0.1/1.0, hai installato la vecchia IPA.

IPA **non firmata**: la compilazione GitHub non la installa direttamente. L'iPhone deve firmarla tramite un metodo di installazione autorizzato.

## B. Sul telefono del tuo amico: SideStore (gratuito, rinnovo dal telefono)

**Non è sufficiente installare SideStore come app qualsiasi:** serve una configurazione iniziale con un computer e il dispositivo del proprietario.

1. Sul computer del proprietario scarica SideStore e iloader dalle pagine ufficiali: https://docs.sidestore.io/docs/installation/install . Segui i prerequisiti correnti della guida.
2. Collega **il suo iPhone** via USB, autorizza il computer ed esegui l'installazione iniziale di SideStore via iloader.
3. Sul suo iPhone abilita Modalità sviluppatore, autorizza il proprio profilo in **Impostazioni → Generali → VPN e gestione dispositivo**, e configura `LocalDevVPN` come richiesto dalla guida corrente.
4. Accedi a SideStore con **il suo Apple Account**: non condividere password o codici OTP con altri.
5. Apri SideStore → **My Apps**, esegui il primo **Refresh di SideStore**, quindi importa `UFOBridge.ipa` mediante il flusso ufficiale per le app IPA.
6. Apri UFO Bridge, entra nella sezione **Configura**, inserisci seriale/IP dell'impianto solo sul suo telefono e usa esclusivamente il PIN utente autorizzato.
7. Ogni pochi giorni (prima dei 7 giorni di scadenza): apri `LocalDevVPN` e SideStore → **My Apps → Refresh**. Dopo la prima configurazione non serve avere il computer acceso. SideStore può tentare aggiornamenti in background, ma conviene controllare manualmente la scadenza.

La configurazione SideStore può richiedere un nuovo abbinamento se si ripristina/aggiorna iOS, ed esistono limiti Apple per i profili gratuiti. **Non esiste una firma gratuita permanente** per questa modalità di sviluppo.

## C. Prova responsabile sulla centralina

1. Conserva il telecomando ufficiale e un metodo di emergenza di disattivazione. Non testare comandi che producono nebbia.
2. Identifica modello/firmware, IP corretto (non presumere che `192.168.1.1` sia il nebbiogeno), porta e seriale; chiedi al proprietario la conferma dei dati.
3. Collega l'iPhone alla stessa rete Wi-Fi; in **Configura** prova **Bonjour** e **Trova IP**. Gli IP candidati **non sono una verifica di identità**: controlla l'indirizzo nel router o nella centralina.
4. In **Impianto** inserisci PIN utente, avvia login locale e verifica che compaia **AUTENTICATO**, le partizioni e uno stato letto realmente.
5. In **Diagnosi** usa **Condividi riepilogo senza credenziali** se qualcosa non funziona. Non pubblicare PIN, seriale e schermate che li mostrano.
6. Verifica **Cloud Ksenia** da rete cellulare solo dopo aver confermato l'accesso autorizzato SecureWeb. La connessione remota potrebbe richiedere l'autorizzazione del servizio Ksenia, non solo seriale e PIN.
7. Se il login, la lettura o il cloud falliscono, non usare l'app come unico sistema di sicurezza. Chiedi all'installatore/fornitore di verificare il modello, firmware, account cloud e certificati.

## D. Alternative senza rinnovo settimanale

- Apple Developer Program (~99 USD/anno): possibilità di compilare e distribuire build firmate per dispositivi autorizzati; provisioning e certificati hanno comunque scadenze.
- TestFlight: ogni build dura **fino a 90 giorni**; non è permanente.
- App Store: niente rinnovo settimanale per l'utente, ma l'app richiede approvazione Apple, distribuzione corretta e diritti sull'icona/marchio UFO Gold. Per un'app non ufficiale è prudente usare un'icona distinta e dichiararne la natura.

Fonti: https://docs.sidestore.io/docs/installation/install ; https://docs.sidestore.io/docs/faq ; https://developer.apple.com/help/account/basics/about-your-developer-account/ ; https://developer.apple.com/testflight/
