# TechSolution UFO Bridge — Release 1.0 (build sorgente, da convalidare)

Data: 8 novembre 2026. Compatibile con iPhone iOS 17 o successivo.

## Cosa è implementato
- Icona UFO Gold ricavata dall’APK caricato dall’utente.
- Configurazione seriale (16 cifre), IP, porta e WSS locale; modalità cloud SecureWeb.
- Connessione WebSocket `KS_WSOCK` e login tramite PIN utente originale.
- Costruzione messaggi JSON con CRC16 coerente con l'implementazione APK.
- Richieste READ per PARTITIONS/ZONES e STATUS_ALL; interpretazione `STATUS_PARTITIONS.ARM` e `STATUS_SYSTEM.ARM.S` solo se i dati arrivano realmente dalla centrale.
- Comandi espliciti di inserimento/disinserimento partizioni **solo locale**, dopo login, lettura di stato valida e conferma, con PIN autorizzato.
- Link al sito originale SecureWeb per gestione cloud attraverso il servizio del produttore.
- Ricerca passiva Bonjour e scansione IP/TCP 443 della rete privata Wi-Fi /24 su avvio esplicito. Gli IP trovati **non sono una conferma dell’identità della centralina**.
- Nessun salvataggio del PIN, **WSS obbligatorio per l'invio del PIN** (certificato verificato da iOS), nessuna erogazione di nebbia.

## Cosa NON è verificato
- Non abbiamo un hardware reale collegato né un Mac/Xcode in questo ambiente.
- Cloud remoto: il login al relay potrebbe richiedere altri privilegi/registrazione e i controlli utente possono dipendere dalla configurazione originale.
- I nomi e campi degli stati dipendono da firmware, licenza e modello. L’app *non è ancora una sostituzione certificata* dell’originale.
- Non è implementato il pairing radio, gestione sensori o firmware. Non provare azioni operative finché il proprietario/installatore non conferma il comportamento.

## Aggiornamento su GitHub esistente
Il tuo repository `techsolutionmalta/ufogold` contiene un file ZIP chiamato `TechSolution-UFO-iOS-CloudBuild.zip`.
Sostituiscilo con il nuovo ZIP omonimo allegato. Il workflow `blank.yml` già configurato estrae automaticamente quell’archivio. **Non caricare i file sorgente in un ulteriore sotto-folder**.

1. GitHub → repository → elimina vecchio `TechSolution-UFO-iOS-CloudBuild.zip` → Commit changes.
2. Add file → Upload files → scegli il nuovo ZIP con lo stesso nome → Commit changes.
3. Actions → Compila UFO Bridge per iPhone → Run workflow su `main`. Non Re-run di una build precedente.
4. Dopo build verde, scarica il nuovo Artifact/IPA, estraine il file `.ipa` e usa Sideloadly.
5. Mantieni il medesimo bundle identifier per sostituire l’app precedente (il programma di firma deve usare lo stesso Apple Account).

## Test con il proprietario
1. Collegamento locale con seriale, IP verificato nel router e PIN fornito dal proprietario.
2. Verificare che la risposta `LOGIN_RES` sia OK e che le partizioni appaiano.
3. Verificare la lettura dello stato; **senza** attivare la nebbia.
4. In rete cellulare, ripetere login cloud; se il backend richiede un login diverso, usare il portale ufficiale SecureWeb.
5. Non usare il sistema come unico metodo di disarmo fino a test riusciti e approvazione dell’installatore.

## Sicurezza
Nessun PIN o credenziale va caricato su GitHub; il PIN viene mantenuto soltanto nella RAM dell'app e azzerato alla disconnessione. Non eseguire prove di attivazione del nebbiogeno in ambienti occupati. Evita di disattivare le protezioni TLS.

## Stato verifica tecnica del pacchetto
- Swift: controllo sintattico superato con `swiftc -frontend -parse` (Linux).
- Xcode: progetto `.pbxproj` controllato con `plutil`; icona e `Info.plist` presenti.
- **Compilazione iOS su Xcode non eseguita in questo ambiente Linux.** Il workflow macOS GitHub Actions è il test di compilazione da eseguire prima dell'installazione.
