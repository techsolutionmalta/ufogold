TechSolution UFO Bridge 1.0 — apri README-RELEASE-1.0.md per build, note di sicurezza e limiti.
