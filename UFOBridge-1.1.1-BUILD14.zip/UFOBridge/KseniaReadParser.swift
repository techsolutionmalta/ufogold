import Foundation

struct UFORadioDevice: Identifiable, Equatable {
    let id: String
    let name: String
    let family: String
    let signal: String
    let battery: String
    let warning: String
    let lastTransmission: String
}

struct UFOScenario: Identifiable, Equatable {
    let id: String
    let name: String
    let requiresPIN: Bool
    var isFogRelated: Bool {
        let name = self.name.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        return ["sparo", "nebbia", "fog", "emissione", "scarica"].contains { name.contains($0) }
    }
}

struct UFOOutput: Identifiable, Equatable {
    let id: String
    let name: String
    let state: String
}

struct UFOReadSnapshot {
    let scenarios: [UFOScenario]?
    let outputs: [UFOOutput]?
    let radio: [UFORadioDevice]?
}

/// Decoder difensivo dei payload READ_RES / REALTIME di lares 4.0.
/// Legge soltanto categorie note, anche quando il server le annida sotto il seriale.
/// Non conserva né registra PIN, seriale, token o interi pacchetti di rete.
enum KseniaReadParser {
    private static func string(_ value: Any?) -> String {
        if let text = value as? String { return text }
        if let number = value as? NSNumber { return number.stringValue }
        return ""
    }

    private static func arrays(for key: String, in value: Any, depth: Int = 0) -> [[[String: Any]]] {
        guard depth < 6 else { return [] }
        if let object = value as? [String: Any] {
            var result: [[[String: Any]]] = []
            for (rawKey, child) in object {
                if rawKey.uppercased() == key, let records = child as? [[String: Any]] {
                    result.append(records)
                } else if child is [String: Any] {
                    result.append(contentsOf: arrays(for: key, in: child, depth: depth + 1))
                }
            }
            return result
        }
        return []
    }

    private static func records(for key: String, in value: Any) -> [[String: Any]]? {
        let matches = arrays(for: key, in: value)
        guard !matches.isEmpty else { return nil }
        var result: [[String: Any]] = []
        for records in matches { result.append(contentsOf: records) }
        return result
    }

    private static func title(_ row: [String: Any], fallback: String) -> String {
        for key in ["DES", "DESCRIPTION", "NAME", "LABEL"] {
            let value = string(row[key]).trimmingCharacters(in: .whitespacesAndNewlines)
            if !value.isEmpty { return value }
        }
        return fallback
    }

    static func parse(_ payload: [String: Any]) -> UFOReadSnapshot {
        let scenarios: [UFOScenario]?
        if let records = records(for: "SCENARIOS", in: payload) {
            var byID: [String: UFOScenario] = [:]
            for row in records {
                let id = string(row["ID"])
                guard !id.isEmpty else { continue }
                let pin = string(row["PIN"]).uppercased()
                byID[id] = UFOScenario(id: id, name: title(row, fallback: "Scenario \(id)"),
                                       requiresPIN: pin == "T" || pin == "TRUE")
            }
            scenarios = byID.values.sorted { ($0.name, $0.id) < ($1.name, $1.id) }
        } else { scenarios = nil }

        let configOutputs = records(for: "OUTPUTS", in: payload)
        let statusOutputs = records(for: "STATUS_OUTPUTS", in: payload)
        let outputs: [UFOOutput]?
        if configOutputs != nil || statusOutputs != nil {
            var byID: [String: UFOOutput] = [:]
            for row in configOutputs ?? [] {
                let id = string(row["ID"])
                guard !id.isEmpty else { continue }
                byID[id] = UFOOutput(id: id, name: title(row, fallback: "Uscita \(id)"), state: "Non verificato")
            }
            for row in statusOutputs ?? [] {
                let id = string(row["ID"])
                guard !id.isEmpty else { continue }
                let state = string(row["STA"]).isEmpty ? string(row["S"]) : string(row["STA"])
                let old = byID[id]
                byID[id] = UFOOutput(id: id, name: old?.name ?? title(row, fallback: "Uscita \(id)"),
                                     state: state.isEmpty ? "Non disponibile" : state)
            }
            outputs = byID.values.sorted { $0.name < $1.name }
        } else { outputs = nil }

        let radioGroups: [(key: String, label: String)] = [
            ("WLS_SENSORS", "Sensore"), ("WLS_SIRENS", "Sirena"),
            ("WLS_IOS", "Modulo I/O"), ("WLS_REPEATERS", "Ripetitore"),
            ("WLS_KEYPADS", "Tastiera")
        ]
        var hasRadio = false
        var radioByID: [String: UFORadioDevice] = [:]
        for group in radioGroups {
            let configuration = records(for: group.key, in: payload)
            let status = records(for: "STATUS_" + group.key, in: payload)
            if configuration != nil || status != nil { hasRadio = true }
            for row in configuration ?? [] {
                let id = string(row["ID"])
                guard !id.isEmpty else { continue }
                let key = "\(group.key)-\(id)"
                radioByID[key] = UFORadioDevice(id: key,
                    name: title(row, fallback: "\(group.label) \(id)"), family: group.label,
                    signal: "N/D", battery: "N/D", warning: "", lastTransmission: "N/D")
            }
            for row in status ?? [] {
                let id = string(row["ID"])
                guard !id.isEmpty else { continue }
                let key = "\(group.key)-\(id)"
                let old = radioByID[key]
                let rf = string(row["RF_STA"])
                let battery = string(row["BLVL"])
                let info = (row["INFO"] as? [String] ?? []).joined(separator: ", ")
                let warning = (rf == "L" ? "Dispositivo radio non raggiungibile" : "") +
                              (!info.isEmpty ? (rf == "L" ? "; " : "") + "Eventi: \(info)" : "")
                radioByID[key] = UFORadioDevice(id: key,
                    name: old?.name ?? title(row, fallback: "\(group.label) \(id)"),
                    family: group.label,
                    signal: rf.isEmpty ? "N/D" : (Int(rf) != nil ? "\(rf) dBm" : rf),
                    battery: battery.isEmpty ? "N/D" : battery,
                    warning: warning, lastTransmission: string(row["LAST_RF_TX"]).isEmpty ? "N/D" : string(row["LAST_RF_TX"]))
            }
        }
        let radio = hasRadio ? radioByID.values.sorted { $0.name < $1.name } : nil
        return UFOReadSnapshot(scenarios: scenarios, outputs: outputs, radio: radio)
    }
}
