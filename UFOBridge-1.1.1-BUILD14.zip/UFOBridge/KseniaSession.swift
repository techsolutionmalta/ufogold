import Foundation
import Combine

struct UFOPartition: Identifiable {
    let id: String
    let label: String
    let detail: String
    let verifiedState: Bool
}

/// Sessione utente PIN: login, lettura stato e azioni esplicite sulla propria centrale.
/// TLS è sempre verificato dal sistema; non viene usato alcun bypass di certificato.
@MainActor
final class KseniaSession: NSObject, ObservableObject, URLSessionWebSocketDelegate {
    enum Phase: Equatable {
        case idle, connecting, connected, authenticating, authenticated, error(String)
    }
    @Published private(set) var phase: Phase = .idle
    @Published private(set) var diagnostic = "Nessuna sessione attiva."
    @Published private(set) var partitions: [UFOPartition] = []
    @Published private(set) var zonesCount: Int? = nil
    @Published private(set) var scenarios: [UFOScenario] = []
    @Published private(set) var outputs: [UFOOutput] = []
    @Published private(set) var radioDevices: [UFORadioDevice] = []
    @Published private(set) var generalStatus = "Stato non ancora ricevuto dalla centrale"
    @Published private(set) var lastUpdate: Date? = nil

    private var urlSession: URLSession?
    private var socket: URLSessionWebSocketTask?
    private var attempt = UUID()
    private var sender = ""
    private var receiver = ""
    private var idLogin: String?
    private var validPin = ""   // Solo RAM; non viene scritto in archivio/log.
    private var currentID = 10
    private var pendingCommands: [String: String] = [:]
    private var cloud = false
    private var hasReceivedVerifiedState = false
    private var lastVerifiedStateAt: Date? = nil
    private var lastScenarioSentAt: Date? = nil

    var isLoggedIn: Bool { if case .authenticated = phase { return true }; return false }
    var isBusy: Bool { switch phase { case .connecting, .authenticating: return true; default: return false } }
    var canCommandPartitions: Bool {
        guard isLoggedIn && !cloud && hasReceivedVerifiedState,
              let verified = lastVerifiedStateAt, Date().timeIntervalSince(verified) < 60 else { return false }
        return partitions.contains(where: { $0.verifiedState })
    }

    var canExecuteScenarioLocally: Bool {
        guard isLoggedIn && !cloud && hasReceivedVerifiedState,
              let verified = lastVerifiedStateAt,
              Date().timeIntervalSince(verified) < 30 else { return false }
        return !scenarios.isEmpty
    }

    /// Richiede un ID scenario effettivamente annunciato dalla centrale.
    /// Mai generare comandi radio direttamente: gli apparati WLS sono gestiti dall'hardware lares.
    /// Un riscontro OK del server NON certifica l'esecuzione fisica dell'azione.
    func executeScenario(id: String, confirmedPin: String, isOnSite: Bool,
                         areaCleared: Bool) {
        guard canExecuteScenarioLocally, scenarios.contains(where: { $0.id == id && $0.isFogRelated }) else {
            diagnostic = "Scenario nebbia non verificato o sessione non locale: comando bloccato."
            return
        }
        guard confirmedPin == validPin, !confirmedPin.isEmpty, let idLogin else {
            diagnostic = "PIN di conferma non valido."
            return
        }
        guard isOnSite && areaCleared else {
            diagnostic = "Conferma sul posto e verifica area libera obbligatorie."
            return
        }
        if let previous = lastScenarioSentAt, Date().timeIntervalSince(previous) < 30 {
            diagnostic = "Protezione doppio comando: riprova dopo almeno 30 secondi."
            return
        }
        lastScenarioSentAt = Date()
        diagnostic = "Invio scenario richiesto; attendere il riscontro e verificare fisicamente."
        Task {
            await send("CMD_USR", kind: "CMD_EXE_SCENARIO", payload: [
                "ID_LOGIN": idLogin, "PIN": confirmedPin, "SCENARIO": ["ID": id]
            ])
        }
    }

    func start(host: String, port: String, tls: Bool, serial: String, pin: String,
               remote: Bool) {
        disconnect()
        let serial = serial.trimmingCharacters(in: .whitespacesAndNewlines)
        let pin = pin.trimmingCharacters(in: .whitespacesAndNewlines)
        guard serial.count == 16, serial.allSatisfy({ $0.isNumber }) else {
            phase = .error("Serve il numero seriale della centrale (16 cifre).")
            return
        }
        guard pin.count >= 4, pin.count <= 12 else {
            phase = .error("Inserisci il PIN utente autorizzato (4–12 caratteri).")
            return
        }
        guard remote || tls else {
            phase = .error("Per trasmettere il PIN è obbligatorio usare WSS cifrato.")
            return
        }
        let deviceSenderKey = "ufoBridgeSenderV1"
        if let stored = UserDefaults.standard.string(forKey: deviceSenderKey), !stored.isEmpty {
            sender = stored
        } else {
            let created = UUID().uuidString.lowercased() + "-l4"
            UserDefaults.standard.set(created, forKey: deviceSenderKey)
            sender = created
        }
        receiver = serial
        validPin = pin
        cloud = remote
        idLogin = nil
        partitions = []; scenarios = []; outputs = []; radioDevices = []
        lastScenarioSentAt = nil
        hasReceivedVerifiedState = false
        lastVerifiedStateAt = nil
        zonesCount = nil
        generalStatus = "Stato non ancora ricevuto dalla centrale"
        let endpoint: URL?
        if remote {
            var url = URLComponents()
            url.scheme = "wss"; url.host = "api.kseniasecureweb.com"; url.port = 443
            url.path = "/KseniaWsock"
            url.queryItems = [URLQueryItem(name: "serialNumber", value: serial),
                              URLQueryItem(name: "sender", value: sender)]
            endpoint = url.url
        } else {
            let safeHost = host.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !safeHost.isEmpty, !safeHost.contains("/"), !safeHost.contains(":"),
                  !safeHost.contains(" "), let p = Int(port), (1...65535).contains(p) else {
                phase = .error("IP o porta locale non validi."); validPin = ""; return
            }
            var url = URLComponents()
            url.scheme = tls ? "wss" : "ws"
            url.host = safeHost; url.port = p; url.path = "/KseniaWsock"
            endpoint = url.url
        }
        guard let endpoint else { phase = .error("Indirizzo non valido."); validPin = ""; return }
        phase = .connecting
        diagnostic = remote ? "Connessione al relay SecureWeb…" : "Connessione alla centralina locale…"
        let id = UUID(); attempt = id
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 15
        configuration.timeoutIntervalForResource = 25
        let session = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
        let task = session.webSocketTask(with: endpoint, protocols: ["KS_WSOCK"])
        urlSession = session; socket = task
        task.resume()
        Task { [weak self] in
            try? await Task.sleep(nanoseconds: 15_000_000_000)
            guard let self, self.attempt == id, self.isBusy else { return }
            self.fail("Timeout di collegamento: controlla IP, rete, cloud o certificato.")
        }
    }

    nonisolated func urlSession(_ session: URLSession, webSocketTask: URLSessionWebSocketTask,
                               didOpenWithProtocol protocol: String?) {
        Task { @MainActor [weak self] in
            guard let self, self.socket === webSocketTask else { return }
            guard `protocol` == "KS_WSOCK" else {
                self.fail("Il server non ha confermato il protocollo Ksenia KS_WSOCK.")
                return
            }
            self.phase = .connected
            self.diagnostic = "WebSocket connesso: invio login utente autorizzato…"
            let id = self.attempt
            self.receiveLoop(webSocketTask, id: id)
            await self.authenticate()
        }
    }

    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask,
                               didCompleteWithError error: Error?) {
        Task { @MainActor [weak self] in
            guard let self, self.socket === task else { return }
            if let error { self.fail("Connessione terminata: \(error.localizedDescription)") }
            else { self.fail("Il server ha chiuso la connessione.") }
        }
    }

    private func send(_ cmd: String, kind: String, payload: [String: Any]) async {
        guard let socket else { return }
        currentID = (currentID % 65534) + 1
        let id = currentID
        do {
            let packet = try KseniaProtocol.packet(sender: sender, receiver: receiver,
                                                    command: cmd, kind: kind, payload: payload, id: id)
            pendingCommands[String(id)] = cmd
            try await socket.send(.string(packet))
        } catch {
            fail("Invio \(cmd) fallito: \(error.localizedDescription)")
        }
    }

    private func authenticate() async {
        phase = .authenticating
        await send("LOGIN", kind: "USER", payload: ["PIN": validPin])
    }

    private func requestStates() async {
        guard let idLogin else { return }
        await send("READ", kind: "MULTI_TYPES", payload: [
            "ID_LOGIN": idLogin, "ID_READ": "1",
            "TYPES": ["PARTITIONS", "ZONES", "SCENARIOS", "OUTPUTS",
                      "WLS_SENSORS", "WLS_SIRENS", "WLS_IOS", "WLS_REPEATERS"]
        ])
        await send("READ", kind: "STATUS_ALL", payload: ["ID_LOGIN": idLogin, "ID_READ": "1"])
    }

    func refresh() { guard isLoggedIn else { return }; Task { await requestStates() } }

    /// Modifica esplicita: consentita solo in locale, con login e reinserimento PIN.
    func changePartition(id: String, disarm: Bool, confirmedPin: String) {
        guard canCommandPartitions, partitions.contains(where: { $0.id == id && $0.verifiedState }) else {
            diagnostic = "Comando non disponibile: attendi il login locale e lo stato certificato della partizione."
            return
        }
        guard confirmedPin == validPin, !confirmedPin.isEmpty, let idLogin else {
            diagnostic = "PIN non valido per questa sessione."
            return
        }
        Task {
            await send("CMD_USR", kind: "CMD_ARM_PARTITION", payload: [
                "ID_LOGIN": idLogin, "PIN": confirmedPin,
                "PARTITION": ["ID": id, "MOD": disarm ? "D" : "A"]
            ])
        }
    }

    private func receiveLoop(_ task: URLSessionWebSocketTask, id: UUID) {
        Task { [weak self] in
            while let self, self.attempt == id, self.socket === task {
                do {
                    let message = try await task.receive()
                    switch message {
                    case .string(let value): self.process(value)
                    case .data(let data):
                        if let value = String(data: data, encoding: .utf8) { self.process(value) }
                    @unknown default: break
                    }
                } catch {
                    if self.attempt == id, self.socket === task {
                        self.fail("Connessione interrotta: \(error.localizedDescription)")
                    }
                    return
                }
            }
        }
    }

    private func text(_ value: Any?) -> String {
        if let string = value as? String { return string }
        if let number = value as? NSNumber { return number.stringValue }
        return ""
    }

    private func process(_ input: String) {
        guard let data = input.data(using: .utf8),
              let message = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
        let command = text(message["CMD"]).uppercased()
        let payload = message["PAYLOAD"] as? [String: Any] ?? [:]
        let result = text(payload["RESULT"]).uppercased().trimmingCharacters(in: .whitespacesAndNewlines)
        if let responseID = message["ID"] { pendingCommands.removeValue(forKey: text(responseID)) }
        switch command {
        case "LOGIN_RES":
            guard result == "OK", !text(payload["ID_LOGIN"]).isEmpty else {
                fail("Login rifiutato dalla centrale (PIN, privilegi o accesso remoto).")
                return
            }
            idLogin = text(payload["ID_LOGIN"])
            phase = .authenticated
            diagnostic = "Login riuscito. Lettura degli stati in corso…"
            Task { await requestStates() }
        case "READ_RES", "REALTIME", "REALTIME_RES":
            if result == "FAIL" {
                let detail = text(payload["RESULT_DETAIL"])
                diagnostic = "Lettura rifiutata dalla centrale (\(detail.isEmpty ? "errore non specificato" : detail))."
            } else {
                applyRead(payload)
            }
        case "CMD_USR_RES":
            diagnostic = result == "OK" ? "Comando accettato dalla centrale. Aggiorno lo stato…" :
                "Comando non accettato dalla centrale: \(text(payload["RESULT_DETAIL"]))"
            if result == "OK" { refresh() }
        case "GENERIC":
            if result != "OK" { diagnostic = "Risposta centrale: \(text(payload["RESULT_DETAIL"]))" }
        default:
            break
        }
    }

    private func applyRead(_ payload: [String: Any]) {
        let parsed = KseniaReadParser.parse(payload)
        if let scenariosFromPanel = parsed.scenarios { scenarios = scenariosFromPanel }
        if let outputFromPanel = parsed.outputs {
            outputs = outputFromPanel.map { value in
                if value.name.hasPrefix("Uscita "),
                   let original = outputs.first(where: { $0.id == value.id }),
                   !original.name.hasPrefix("Uscita ") {
                    return UFOOutput(id: value.id, name: original.name, state: value.state)
                }
                return value
            }
        }
        if let radioFromPanel = parsed.radio {
            radioDevices = radioFromPanel.map { value in
                if value.name.contains("radio") || value.name.hasPrefix(value.family),
                   let original = radioDevices.first(where: { $0.id == value.id }),
                   !original.name.hasPrefix(original.family) {
                    return UFORadioDevice(id: value.id, name: original.name,
                        family: value.family, signal: value.signal, battery: value.battery,
                        warning: value.warning, lastTransmission: value.lastTransmission)
                }
                return value
            }
        }
        if let raw = payload["PARTITIONS"] as? [[String: Any]] {
            for row in raw {
                let id = text(row["ID"])
                guard !id.isEmpty else { continue }
                let title = text(row["DES"]).isEmpty ? text(row["NAME"]) : text(row["DES"])
                let label = title.isEmpty ? "Partizione \(id)" : title
                if let index = partitions.firstIndex(where: { $0.id == id }) {
                    let old = partitions[index]
                    partitions[index] = UFOPartition(id: id, label: label, detail: old.detail,
                                                      verifiedState: old.verifiedState)
                } else {
                    partitions.append(UFOPartition(id: id, label: label, detail: "Stato non letto", verifiedState: false))
                }
            }
        }
        let embedded = payload[receiver] as? [String: Any]
        let states = (payload["STATUS_PARTITIONS"] as? [[String: Any]]) ??
                     (embedded?["STATUS_PARTITIONS"] as? [[String: Any]]) ?? []
        for state in states {
            let id = text(state["ID"])
            guard !id.isEmpty else { continue }
            let arm = text(state["ARM"]).uppercased()
            let armDescription: String
            switch arm {
            case "D": armDescription = "Disinserita"
            case "DA": armDescription = "Inserita con ritardo"
            case "IA": armDescription = "Inserita immediata"
            case "IT": armDescription = "Tempo di ingresso"
            case "OT": armDescription = "Tempo di uscita"
            default: armDescription = "Stato non riconosciuto"
            }
            let alarm = text(state["AST"]).uppercased()
            let tamper = text(state["TST"]).uppercased()
            var detail = armDescription
            if alarm == "AL" { detail += " · ALLARME ATTIVO" }
            if alarm == "AM" { detail += " · Memoria allarme" }
            if tamper == "TAM" { detail += " · Sabotaggio" }
            let verified = ["D", "DA", "IA", "IT", "OT"].contains(arm)
            if verified { hasReceivedVerifiedState = true; lastVerifiedStateAt = Date() }
            if let index = partitions.firstIndex(where: { $0.id == id }) {
                let old = partitions[index]
                partitions[index] = UFOPartition(id: id, label: old.label, detail: detail,
                                                  verifiedState: verified)
            } else {
                partitions.append(UFOPartition(id: id, label: "Partizione \(id)",
                                               detail: detail, verifiedState: verified))
            }
        }
        if let zones = payload["ZONES"] as? [Any] { zonesCount = zones.count }
        if let system = (payload["STATUS_SYSTEM"] as? [[String: Any]])?.first,
           let arm = system["ARM"] as? [String: Any] {
            let status = text(arm["S"]).uppercased()
            switch status {
            case "D": generalStatus = "Disinserito (dato centralina)"
            case "T": generalStatus = "Inserimento totale (dato centralina)"
            case "P": generalStatus = "Inserimento parziale (dato centralina)"
            default: generalStatus = "Stato generale: \(status.isEmpty ? "sconosciuto" : status)"
            }
        }
        lastUpdate = Date()
        diagnostic = "Risposta di lettura ricevuta. Eventuali stati delle partizioni sono aggiornati." 
    }

    func safeDiagnosticSummary(mode: String) -> String {
        // Nessun PIN, seriale, IP, token o payload grezzo lascia il dispositivo.
        let authStatus = isLoggedIn ? "Autenticato" : "Non autenticato"
        let date = lastUpdate?.formatted(date: .abbreviated, time: .standard) ?? "Nessuna"
        return """
        UFO Bridge 1.1.1 RC (build 14)
        Connessione: \(mode)
        Accesso: \(authStatus)
        Partizioni ricevute: \(partitions.count)
        Scenari ricevuti: \(scenarios.count)
        Periferiche radio ricevute: \(radioDevices.count)
        Uscite ricevute: \(outputs.count)
        Stati locali verificati: \(hasReceivedVerifiedState ? "Sì" : "No")
        Ultimo aggiornamento: \(date)
        Nessuna credenziale o identificatore impianto incluso.
        """
    }

    private func closeTransport() {
        socket?.cancel(with: .normalClosure, reason: nil)
        urlSession?.invalidateAndCancel()
        socket = nil; urlSession = nil
    }
    private func fail(_ message: String) {
        phase = .error(message); diagnostic = message
        validPin = ""; idLogin = nil
        closeTransport()
    }
    func disconnect() {
        attempt = UUID()
        closeTransport()
        validPin = ""; idLogin = nil
        partitions = []; scenarios = []; outputs = []; radioDevices = []; lastScenarioSentAt = nil; zonesCount = nil; lastUpdate = nil; hasReceivedVerifiedState = false; lastVerifiedStateAt = nil
        generalStatus = "Stato non ancora ricevuto dalla centrale"
        phase = .idle; diagnostic = "Sessione chiusa."
    }
}
