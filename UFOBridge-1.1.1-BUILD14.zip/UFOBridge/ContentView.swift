import SwiftUI

private struct PartitionAction: Identifiable {
    var id: String { partitionID + (disarm ? "-disarm" : "-arm") }
    let partitionID: String
    let partitionName: String
    let disarm: Bool
}

struct ContentView: View {
    @StateObject private var bridge = KseniaSession()
    @StateObject private var discovery = LocalDiscovery()
    @Environment(\.scenePhase) private var scenePhase

    @AppStorage("ufoBridgeName") private var deviceName = "Nebbiogeno UFO"
    @AppStorage("ufoBridgeHost") private var host = ""
    @AppStorage("ufoBridgePort") private var port = "443"
    @AppStorage("ufoBridgeTLS") private var secure = true
    @AppStorage("ufoBridgeSerial") private var serialNumber = ""
    @AppStorage("ufoBridgeMode") private var mode = 0

    @State private var pin = ""
    @State private var revealPIN = false
    @State private var action: PartitionAction?
    @State private var confirmPin = ""
    @State private var confirmationNotice = ""
    @State private var tab = 0
    @State private var showSecurityInfo = false
    @State private var selectedScenario: UFOScenario?
    @State private var scenarioPin = ""
    @State private var physicallyPresent = false
    @State private var areaConfirmedFree = false
    // Selezione per questa sessione: non può riutilizzare uno scenario non più
    // presente nella lista aggiornata della centrale.
    @State private var fogScenarioID = ""
    @State private var scenarioMappingConfirmed = false

    private var selectedFogScenario: UFOScenario? {
        bridge.scenarios.first { $0.id == fogScenarioID && $0.isFogRelated }
    }

    private var phaseText: String {
        switch bridge.phase {
        case .idle: return "NON CONNESSO"
        case .connecting: return "COLLEGAMENTO…"
        case .connected: return "COLLEGATO · NON AUTENTICATO"
        case .authenticating: return "VERIFICA PIN…"
        case .authenticated: return "AUTENTICATO"
        case .error: return "ERRORE DI COLLEGAMENTO"
        }
    }
    private var phaseColor: Color {
        switch bridge.phase {
        case .authenticated: return .green
        case .connecting, .authenticating, .connected: return .orange
        case .error: return .red
        case .idle: return .gray
        }
    }

    var body: some View {
        TabView(selection: $tab) {
            NavigationStack { homeScreen.navigationTitle("UFO Gold · Bridge") }
                .tabItem { Label("Impianto", systemImage: "shield.lefthalf.filled") }.tag(0)
            NavigationStack { scenarioScreen.navigationTitle("Scenari · Sparo") }
                .tabItem { Label("Scenari", systemImage: "cloud.fog.fill") }.tag(3)
            NavigationStack { radioScreen.navigationTitle("Periferiche radio") }
                .tabItem { Label("Radio", systemImage: "antenna.radiowaves.left.and.right") }.tag(4)
            NavigationStack { settingsScreen.navigationTitle("Configurazione") }
                .tabItem { Label("Configura", systemImage: "gearshape.2") }.tag(1)
            NavigationStack { diagnosticsScreen.navigationTitle("Diagnostica") }
                .tabItem { Label("Diagnosi", systemImage: "waveform.path.ecg") }.tag(2)
        }
        .tint(.cyan)
        .preferredColorScheme(.dark)
        .onChange(of: mode) { _, _ in
            bridge.disconnect()
            fogScenarioID = ""
            selectedScenario = nil
        }
        .onChange(of: bridge.phase) { _, newValue in
            if case .authenticated = newValue { pin = "" }
        }
        .onChange(of: scenePhase) { _, state in
            if state != .active {
                bridge.disconnect()
                pin = ""
                confirmPin = ""
                action = nil
                selectedScenario = nil
                scenarioPin = ""
                fogScenarioID = ""
            }
        }
        .sheet(item: $selectedScenario, onDismiss: {
            scenarioPin = ""
            physicallyPresent = false
            areaConfirmedFree = false
            scenarioMappingConfirmed = false
        }) { item in
            NavigationStack {
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        Label("Potenziale attivazione fisica", systemImage: "exclamationmark.triangle.fill")
                            .font(.headline).foregroundStyle(.orange)
                        Text("Scenario della centrale: \(item.name)").font(.title3.bold())
                        Text("L'emissione di nebbia può azzerare la visibilità e causare panico o incidenti. Il PIN da solo NON rende sicura l'attivazione. Usa il comando solo sul posto, dopo aver controllato le condizioni previste dal produttore.")
                            .font(.subheadline)
                        Text("Scenario letto dalla centrale: ID \(item.id). Verifica con il proprietario o l'installatore che questo ID comandi proprio il nebbiogeno.")
                            .font(.caption).foregroundStyle(.secondary)
                        Toggle("Confermo che scenario e ID corrispondono al nebbiogeno", isOn: $scenarioMappingConfirmed)
                        if item.isFogRelated {
                            Text("ATTENZIONE: questo scenario sembra collegato allo sparo del nebbiogeno.")
                                .foregroundStyle(.red).font(.subheadline.bold())
                        }
                        Toggle("Sono sul posto e ho l'autorizzazione del proprietario", isOn: $physicallyPresent)
                        Toggle("Ho verificato che l'area è libera da persone", isOn: $areaConfirmedFree)
                        SecureField("Reinserisci PIN utente", text: $scenarioPin)
                            .textContentType(.oneTimeCode).keyboardType(.numberPad)
                            .padding(12).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 9))
                        Text("Per inviare il comando tieni premuto il riquadro per 3 secondi. Nessun controllo remoto e nessun invio se mancano le conferme.")
                            .font(.caption).foregroundStyle(.secondary)
                        Text("TIENI PREMUTO PER 3 SECONDI")
                            .font(.headline.bold()).frame(maxWidth: .infinity)
                            .padding(.vertical, 17)
                            .background(bridge.canExecuteScenarioLocally && scenarioMappingConfirmed && physicallyPresent && areaConfirmedFree && !scenarioPin.isEmpty ? Color.orange : Color.gray,
                                        in: RoundedRectangle(cornerRadius: 13))
                            .foregroundStyle(.black)
                            .onLongPressGesture(minimumDuration: 3) {
                                guard bridge.canExecuteScenarioLocally, scenarioMappingConfirmed,
                                      physicallyPresent, areaConfirmedFree, !scenarioPin.isEmpty,
                                      item.isFogRelated else { return }
                                bridge.executeScenario(id: item.id, confirmedPin: scenarioPin,
                                    isOnSite: physicallyPresent, areaCleared: areaConfirmedFree)
                                selectedScenario = nil
                            }
                        Text("Il messaggio di accettazione non certifica l'effettiva attivazione fisica.")
                            .font(.caption2).foregroundStyle(.secondary)
                    }.padding(20)
                }.navigationTitle("Autorizzazione scenario")
                .toolbar { ToolbarItem(placement: .cancellationAction) {
                    Button("Annulla") { selectedScenario = nil }
                }}
            }
            .presentationDetents([.large])
        }
        .sheet(item: $action, onDismiss: {
            confirmPin = ""
            confirmationNotice = ""
        }) { selected in
            NavigationStack {
                VStack(alignment: .leading, spacing: 18) {
                    Label("Conferma di sicurezza", systemImage: "lock.shield")
                        .font(.headline)
                    Text("Partizione: \(selected.partitionName)")
                    Text(selected.disarm ? "Richiesta: disinserimento" : "Richiesta: inserimento ritardato")
                        .font(.subheadline).foregroundStyle(.orange)
                    SecureField("Reinserisci il PIN autorizzato", text: $confirmPin)
                        .textContentType(.oneTimeCode)
                        .keyboardType(.numberPad)
                        .padding(12)
                        .background(Color.secondary.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
                    Text("Il comando è disponibile solo dopo login locale e lettura valida dello stato. Prima di utilizzare l’impianto verifica fisicamente le condizioni di sicurezza.")
                        .font(.footnote).foregroundStyle(.secondary)
                    if !confirmationNotice.isEmpty {
                        Text(confirmationNotice).font(.caption).foregroundStyle(.red)
                    }
                    Button(role: .destructive) {
                        guard !confirmPin.isEmpty else {
                            confirmationNotice = "Inserisci nuovamente il PIN."
                            return
                        }
                        bridge.changePartition(id: selected.partitionID, disarm: selected.disarm,
                                               confirmedPin: confirmPin)
                        confirmPin = ""
                        action = nil
                    } label: {
                        Text("Conferma \(selected.disarm ? "disinserimento" : "inserimento")")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(!bridge.canCommandPartitions)
                    Spacer()
                }
                .padding(20)
                .navigationTitle("Autorizzazione")
                .toolbar { ToolbarItem(placement: .cancellationAction) {
                    Button("Annulla") { action = nil }
                }}
            }
            .presentationDetents([.medium, .large])
        }
    }

    private var homeScreen: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                brand
                Text("BUILD 14 • PULSANTE NEBBIA + PIN")
                    .font(.headline.bold())
                    .foregroundStyle(.black)
                    .frame(maxWidth: .infinity)
                    .padding(12)
                    .background(Color.yellow, in: RoundedRectangle(cornerRadius: 12))
                    .accessibilityIdentifier("ufo-build12-visible-marker")
                section {
                    HStack(spacing: 9) {
                        Circle().fill(phaseColor).frame(width: 10, height: 10)
                        Text(phaseText).font(.caption.weight(.semibold)).foregroundStyle(phaseColor)
                    }
                    Text(deviceName).font(.title2.bold())
                    Text(bridge.isLoggedIn ? bridge.generalStatus : "Nessuno stato allarme verificato")
                        .foregroundStyle(.secondary)
                    if let last = bridge.lastUpdate {
                        Text("Ultima lettura: \(last.formatted(date: .omitted, time: .shortened))")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    if let count = bridge.zonesCount {
                        Label("Zone comunicate dalla centrale: \(count)", systemImage: "square.grid.2x2")
                            .font(.subheadline)
                    }
                }
                section {
                    Label("Accesso autorizzato", systemImage: "lock.shield").font(.headline)
                    Text("Inserisci seriale e PIN utente nella scheda Configura. Il PIN resta soltanto nella memoria della sessione e non viene salvato nell'app.")
                        .font(.caption).foregroundStyle(.secondary)
                    if revealPIN { TextField("PIN utente", text: $pin) }
                    else { SecureField("PIN utente", text: $pin) }
                    Toggle("Mostra PIN", isOn: $revealPIN).font(.caption)
                    Button {
                        if bridge.isLoggedIn { bridge.refresh() }
                        else {
                            bridge.start(host: host, port: port, tls: secure,
                                         serial: serialNumber, pin: pin, remote: mode == 1)
                        }
                    } label: {
                        Label(bridge.isLoggedIn ? "Aggiorna dati" : "Collega e accedi",
                              systemImage: bridge.isLoggedIn ? "arrow.clockwise" : "network")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(bridge.isBusy)
                    if bridge.phase != .idle {
                        Button("Disconnetti", role: .cancel) { bridge.disconnect(); pin = "" }
                            .buttonStyle(.bordered)
                    }
                    if case let .error(message) = bridge.phase {
                        Text(message).font(.caption).foregroundStyle(.red)
                    }
                }
                section {
                    Label("Nebbiogeno", systemImage: "cloud.fog.fill").font(.headline)
                    Text("Il pulsante usa solo lo scenario nebbia comunicato dalla centralina; non trasmette codici radio. Disponibile esclusivamente in locale dopo un accesso verificato.")
                        .font(.caption).foregroundStyle(.secondary)
                    let fogChoices = bridge.scenarios.filter { $0.isFogRelated }
                    if fogChoices.isEmpty {
                        Text("Nessuno scenario nebbia disponibile. Accedi alla centrale, premi Aggiorna dati e verifica con l'installatore il nome dello scenario.")
                            .font(.caption).foregroundStyle(.orange)
                    } else {
                        Picker("Scenario nebbiogeno", selection: $fogScenarioID) {
                            Text("Seleziona lo scenario").tag("")
                            ForEach(fogChoices) { candidate in
                                Text("\(candidate.name) · ID \(candidate.id)").tag(candidate.id)
                            }
                        }
                        if let choice = selectedFogScenario {
                            Text("Selezionato: \(choice.name) · ID \(choice.id)")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    Button(role: .destructive) {
                        guard let scenario = selectedFogScenario,
                              bridge.canExecuteScenarioLocally else { return }
                        selectedScenario = scenario
                    } label: {
                        Label("ATTIVA NEBBIA", systemImage: "exclamationmark.triangle.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    .disabled(selectedFogScenario == nil || !bridge.canExecuteScenarioLocally)
                    Text("La conferma richiede PIN reinserito, identificazione scenario, presenza sul posto, area libera e pressione prolungata. Non disponibile da cloud.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                section {
                    HStack {
                        Label("Partizioni", systemImage: "square.stack.3d.up").font(.headline)
                        Spacer()
                        if !bridge.partitions.isEmpty { Text("\(bridge.partitions.count)").foregroundStyle(.secondary) }
                    }
                    if bridge.partitions.isEmpty {
                        Text("Le partizioni appariranno dopo un login e una risposta valida dalla centrale.")
                            .font(.subheadline).foregroundStyle(.secondary)
                    } else {
                        ForEach(bridge.partitions) { item in
                            VStack(alignment: .leading, spacing: 7) {
                                Text(item.label).font(.headline)
                                if !item.detail.isEmpty { Text(item.detail).font(.caption).foregroundStyle(.secondary) }
                                HStack {
                                    Button("Inserisci") {
                                        action = PartitionAction(partitionID: item.id, partitionName: item.label, disarm: false)
                                    }.buttonStyle(.bordered)
                                    Button("Disinserisci", role: .destructive) {
                                        action = PartitionAction(partitionID: item.id, partitionName: item.label, disarm: true)
                                    }.buttonStyle(.bordered)
                                }.disabled(!bridge.canCommandPartitions || !item.verifiedState)
                            }
                            Divider().overlay(Color.white.opacity(0.1))
                        }
                    }
                    Text("I comandi partizioni richiedono login locale. Gli scenari della centrale si gestiscono nella scheda Scenari con conferma di sicurezza.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }.padding(18)
        }.background(Color(red: 0.075, green: 0.09, blue: 0.11))
    }

    private var scenarioScreen: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                section {
                    Label("Scenari dalla centralina", systemImage: "square.stack.3d.up").font(.headline)
                    Text("Gli scenari non vengono inventati dall'app: appaiono solo dopo login e lettura dal dispositivo.")
                        .font(.caption).foregroundStyle(.secondary)
                    if bridge.scenarios.isEmpty {
                        Text("Nessuno scenario letto. Configura l'impianto, esegui il login e premi Aggiorna dati.")
                            .foregroundStyle(.secondary)
                    }
                    ForEach(bridge.scenarios) { scenario in
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Image(systemName: scenario.isFogRelated ? "exclamationmark.triangle" : "square.stack.3d.up")
                                    .foregroundStyle(scenario.isFogRelated ? Color.orange : Color.cyan)
                                Text(scenario.name).font(.subheadline.bold())
                                Spacer()
                                Text("ID \(scenario.id)").font(.caption2).foregroundStyle(.secondary)
                            }
                            if scenario.isFogRelated {
                                Text("Possibile emissione nebbia: usare soltanto sul posto e in sicurezza.")
                                    .font(.caption).foregroundStyle(.orange)
                            }
                            Button(scenario.isFogRelated ? "Conferma scenario nebbia" : "Scenario in sola lettura") {
                                guard scenario.isFogRelated else { return }
                                selectedScenario = scenario
                            }
                                .buttonStyle(.bordered)
                                .disabled(!scenario.isFogRelated || !bridge.canExecuteScenarioLocally)
                        }
                        Divider()
                    }
                    Text("Invio consentito solo in rete locale, con stato recente, PIN, doppia conferma e pressione prolungata. Le operazioni remote restano disabilitate.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                section {
                    Label("Stato protocollo", systemImage: "network").font(.headline)
                    Text(bridge.diagnostic).font(.caption).foregroundStyle(.secondary)
                }
            }.padding(18)
        }.background(Color(red: 0.075, green: 0.09, blue: 0.11))
    }

    private var radioScreen: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                section {
                    Label("Periferiche radio e wireless", systemImage: "antenna.radiowaves.left.and.right")
                        .font(.headline)
                    Text("Stato ricevuto dalla centralina Ksenia: segnale RF, batteria e anomalie. Non si tratta di una trasmissione radio dall'iPhone.")
                        .font(.caption).foregroundStyle(.secondary)
                    if bridge.radioDevices.isEmpty {
                        Text("Nessuna periferica rilevata: collega la centrale e aggiorna i dati.")
                            .foregroundStyle(.secondary)
                    }
                    ForEach(bridge.radioDevices) { device in
                        VStack(alignment: .leading, spacing: 5) {
                            HStack {
                                Text(device.name).font(.subheadline.bold())
                                Spacer()
                                Text(device.family).font(.caption).foregroundStyle(.secondary)
                            }
                            Text("RF: \(device.signal)  ·  Batteria: \(device.battery)")
                                .font(.caption).foregroundStyle(.secondary)
                            if !device.warning.isEmpty {
                                Label(device.warning, systemImage: "exclamationmark.triangle")
                                    .font(.caption).foregroundStyle(.orange)
                            }
                        }
                        Divider()
                    }
                }
                section {
                    Label("Uscite della centralina (sola lettura)", systemImage: "powerplug")
                        .font(.headline)
                    ForEach(bridge.outputs) { output in
                        HStack {
                            Text(output.name)
                            Spacer()
                            Text(output.state).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    if bridge.outputs.isEmpty {
                        Text("Nessuna uscita ancora comunicata.").foregroundStyle(.secondary)
                    }
                    Text("Per abbinare un telecomando RF occorre l'hardware ricevitore Ksenia e la procedura ufficiale della centralina; l'iPhone non clona direttamente i codici radio.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                Button {
                    bridge.refresh()
                } label: {
                    Label("Aggiorna dati radio", systemImage: "arrow.clockwise")
                        .frame(maxWidth: .infinity)
                }.buttonStyle(.borderedProminent).disabled(!bridge.isLoggedIn)
            }.padding(18)
        }.background(Color(red: 0.075, green: 0.09, blue: 0.11))
    }

    private var brand: some View {
        HStack(spacing: 13) {
            Image("AppLogo").resizable().scaledToFit().frame(width: 62, height: 62)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            VStack(alignment: .leading, spacing: 4) {
                Text("TechSolution · UFO Bridge").font(.headline)
                Text("Release 1.1.1 RC • BUILD 14 • NEBBIA + PIN").font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    private var settingsScreen: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                section {
                    Text("IMPIANTO").font(.caption.bold()).foregroundStyle(.secondary)
                    TextField("Nome impianto", text: $deviceName)
                    fieldDivider
                    TextField("Seriale centrale (16 cifre)", text: $serialNumber)
                        .keyboardType(.numberPad).textInputAutocapitalization(.never)
                    Text("Ricavalo dall'etichetta o dall'app originale. Non inviarlo in repository pubblici.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                section {
                    Text("MODALITÀ DI CONNESSIONE").font(.caption.bold()).foregroundStyle(.secondary)
                    Picker("Modalità", selection: $mode) {
                        Text("Rete locale").tag(0)
                        Text("Cloud Ksenia").tag(1)
                    }.pickerStyle(.segmented)
                    if mode == 0 {
                        TextField("IP centralina (es. 192.168.1.50)", text: $host)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                        fieldDivider
                        TextField("Porta (di norma 443)", text: $port).keyboardType(.numberPad)
                        Toggle("TLS sicuro (WSS)", isOn: $secure)
                        if !secure { Text("Il login richiede WSS attivo.").font(.caption).foregroundStyle(.orange) }
                        Text("Non disattivare TLS se la centrale usa un certificato problematico: confronta prima la configurazione dell'impianto.")
                            .font(.caption2).foregroundStyle(.secondary)
                        HStack {
                            Button {
                                if discovery.isSearching { discovery.stop() } else { discovery.search() }
                            } label: {
                                Label("Bonjour", systemImage: "wifi")
                            }.buttonStyle(.bordered)
                            Button {
                                if discovery.isSearching { discovery.stop() } else { discovery.scanLocalSubnet() }
                            } label: {
                                Label(discovery.isSearching ? "Ferma" : "Trova IP", systemImage: "network")
                            }.buttonStyle(.bordered)
                        }
                        Text(discovery.message).font(.caption2).foregroundStyle(.secondary)
                        ForEach(discovery.suggestions, id: \.self) { suggestion in
                            Button {
                                if suggestion.split(separator: ".").count == 4 {
                                    host = suggestion
                                    discovery.stop()
                                }
                            } label: {
                                Label(suggestion, systemImage: "network.badge.shield.half.filled")
                            }.font(.caption).buttonStyle(.bordered)
                        }
                        if let address = URL(string: "https://" + host + ":" + port), !host.isEmpty {
                            Link("Apri interfaccia web locale", destination: address)
                        }
                    } else {
                        Label("Relay: api.kseniasecureweb.com:443", systemImage: "cloud")
                            .font(.subheadline)
                        Text("Connessione remota sperimentale: il relay potrebbe richiedere l’autenticazione SecureWeb del produttore oltre al PIN. I comandi sulle partizioni non sono disponibili da remoto.")
                            .font(.caption).foregroundStyle(.secondary)
                        Link(destination: URL(string: "https://www.kseniasecureweb.com/")!) {
                            Label("Apri il portale ufficiale Ksenia", systemImage: "arrow.up.right.square")
                        }
                    }
                }
                section {
                    Label("Installazione e rinnovo", systemImage: "iphone.and.arrow.forward").font(.headline)
                    Text("Con Apple Account gratuito, l'app scade dopo 7 giorni. SideStore permette di rinnovarla dall'iPhone, dopo la prima installazione tramite computer. UFO Bridge non modifica né rinnova i profili Apple autonomamente.")
                        .font(.caption).foregroundStyle(.secondary)
                    Link("Guida ufficiale SideStore", destination: URL(string: "https://docs.sidestore.io/docs/installation/install")!)
                        .font(.subheadline)
                    Text("La versione Cloud resta sperimentale finché non viene eseguito il test sulla centrale reale.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                section {
                    Text("SICUREZZA").font(.caption.bold()).foregroundStyle(.secondary)
                    Label("Il PIN non viene archiviato", systemImage: "key.horizontal")
                    Label("Verifica TLS standard attiva", systemImage: "lock")
                    Label("Scenari locali con conferma rafforzata", systemImage: "lock.shield")
                    Text("Una connessione riuscita non equivale a certificare che l'impianto sia disinserito.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }.padding(18)
        }.background(Color(red: 0.075, green: 0.09, blue: 0.11))
    }

    private var diagnosticsScreen: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                section {
                    Text("DIAGNOSTICA DELLA SESSIONE").font(.caption.bold()).foregroundStyle(.secondary)
                    Text(phaseText).foregroundStyle(phaseColor).font(.headline)
                    Text(bridge.diagnostic).font(.subheadline)
                    Text("Trasporto: " + (mode == 0 ? "locale" : "cloud") + " · KS_WSOCK")
                        .font(.caption.monospaced()).foregroundStyle(.secondary)
                    Text("Build: 1.1.1 (14) · Protocollo sperimentale")
                        .font(.caption.monospaced()).foregroundStyle(.secondary)
                    ShareLink(item: bridge.safeDiagnosticSummary(mode: mode == 0 ? "locale" : "cloud")) {
                        Label("Condividi riepilogo senza credenziali", systemImage: "square.and.arrow.up")
                    }.font(.subheadline)
                    if let last = bridge.lastUpdate {
                        Text("Ultima risposta: \(last.formatted(date: .abbreviated, time: .standard))")
                            .font(.caption)
                    }
                }
                section {
                    Label("Test in presenza del proprietario", systemImage: "checkmark.shield").font(.headline)
                    Text("""
                         1. Accerta IP e numero seriale dall'impianto.
                         2. Collega il telefono allo stesso Wi-Fi.
                         3. Inserisci il PIN utente autorizzato.
                         4. Esegui login e verifica la lettura delle partizioni.
                         5. Ripeti il login in modalità cloud usando la rete cellulare.
                         6. Controlla fisicamente lo stato prima di usare qualunque comando.
                         """)
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                section {
                    Text("LIMITI DELLA RELEASE 1.0.2 RC").font(.headline)
                    Text("La versione 1.1.1 legge periferiche radio, uscite e scenari; il comando scenario è protetto da PIN e presenza sul posto, ma non è ancora collaudato sul nebbiogeno specifico. L’abbinamento RF, le notifiche push e il login SecureWeb completo richiedono ulteriori verifiche. Un certificato scaduto può impedire TLS.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
            }.padding(18)
        }.background(Color(red: 0.075, green: 0.09, blue: 0.11))
    }

    private var fieldDivider: some View { Divider().overlay(Color.white.opacity(0.12)) }

    private func section<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 13, content: content)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(17)
            .background(Color.white.opacity(0.075), in: RoundedRectangle(cornerRadius: 16))
    }
}
