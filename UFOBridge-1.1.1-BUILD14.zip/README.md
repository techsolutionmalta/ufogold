# UFO Bridge 1.1.1 RC — BUILD 14

Aggiunto nella scheda Impianto il pulsante **ATTIVA NEBBIA** con conferma PIN.

## Comportamento

- Visibile ma disabilitato fino a login locale, lettura recente delle partizioni e selezione esplicita di uno scenario nebbia riconosciuto *dall'impianto*.
- Scenario non scelto automaticamente; solo scenari denominati dalla centralina come sparo/nebbia/fog/emissione/scarica.
- Nella conferma occorre verificare nome e ID con il proprietario/installatore, indicare presenza e area libera, reinserire il PIN della sessione e tenere premuto tre secondi.
- Nessuna attivazione cloud o invio radio diretto dall'iPhone; nessun ID hardcoded; anti-ripetizione 30 secondi. La centrale conserva tutti gli interblocchi fisici.
- L'app non garantisce che un comando accettato corrisponda a emissione reale. Test reale da effettuare solo con installatore e locale sgombro.

## Build

Caricare lo ZIP alla radice del repository GitHub e il file `build14.yml` nella cartella `.github/workflows/`. Il workflow testa sintassi e protocollo, compila con Xcode su runner macOS e genera IPA **non firmata**. Una build verde non prova il funzionamento sul nebbiogeno.

**Non usare questa applicazione come unico controllo dell'impianto di sicurezza.**
