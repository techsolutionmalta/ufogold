import Foundation

func require(_ value: @autoclosure () -> Bool, _ message: String) {
    guard value() else { fputs("ERRORE: \(message)\n", stderr); exit(1) }
}

require(KseniaProtocol.crc16("123456789".utf8) == "0xa69d", "CRC16 originale UFO Gold")

let packet = try KseniaProtocol.packet(
    sender: "D0E1F2A3B4C5-l4", receiver: "1234567890123456", command: "LOGIN",
    kind: "USER", payload: ["PIN": "000000"], id: 17)
let data = packet.data(using: .utf8)!
let object = try JSONSerialization.jsonObject(with: data) as! [String: Any]
let payload = object["PAYLOAD"] as! [String: Any]
require(object["CMD"] as? String == "LOGIN", "comando serializzato")
require(object["PAYLOAD_TYPE"] as? String == "USER", "payload type")
require(payload["PIN"] as? String == "000000", "test payload")
require((object["CRC_16"] as? String)?.hasPrefix("0x") == true, "campo CRC16")
print("OK: CRC16 e struttura JSON testati (nessun accesso a dispositivi)")

let sampleRead: [String: Any] = ["0123456789012345": [
    "SCENARIOS": [["ID": "8", "DES": "Sparo", "PIN": "T"],
                  ["ID": "9", "DES": "Illuminazione"]],
    "OUTPUTS": [["ID": "1", "DES": "Uscita nebbia"]],
    "STATUS_OUTPUTS": [["ID": "1", "STA": "OFF"]],
    "WLS_SENSORS": [["ID": "3", "DES": "Contatto finestra"]],
    "STATUS_WLS_SENSORS": [["ID": "3", "RF_STA": "-54", "BLVL": "BOK", "LAST_RF_TX": "25", "INFO": []]],
    "STATUS_WLS_SIRENS": [["ID": "1", "RF_STA": "L", "INFO": ["TMP"]]]
]]
let snap = KseniaReadParser.parse(sampleRead)
require(snap.scenarios?.count == 2, "scenari da payload annidato")
require(snap.scenarios?.first(where: { $0.id == "8" })?.isFogRelated == true, "sparo classificato come possibile nebbia")
require(snap.scenarios?.first(where: { $0.id == "8" })?.requiresPIN == true, "autorizzazione scenario")
require(snap.outputs?.first(where: { $0.id == "1" })?.name == "Uscita nebbia", "nome uscita configurata")
require(snap.outputs?.first?.state == "OFF", "stato uscita")
require(snap.radio?.count == 2, "due periferiche radio")
require(snap.radio?.first(where: { $0.id == "WLS_SENSORS-3" })?.signal == "-54 dBm", "potenza RF")
require(snap.radio?.first(where: { $0.id == "WLS_SENSORS-3" })?.battery == "BOK", "livello batteria")
require(snap.radio?.first(where: { $0.id == "WLS_SIRENS-1" })?.warning.contains("non raggiungibile") == true,
        "allerta radio offline")
require(KseniaReadParser.parse(["UNRELATED": 1]).scenarios == nil, "assenza non equivale a lista vuota")
print("OK: scenari, uscite e dispositivi radio da payload annidato")
