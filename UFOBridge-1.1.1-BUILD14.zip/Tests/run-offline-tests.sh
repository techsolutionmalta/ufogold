#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)"
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT
cp "$ROOT/Tests/main.swift" "$TEMP_DIR/main.swift"
swiftc "$ROOT/UFOBridge/KseniaProtocol.swift" "$ROOT/UFOBridge/KseniaReadParser.swift" "$TEMP_DIR/main.swift" -o "$TEMP_DIR/ufo-smoke"
"$TEMP_DIR/ufo-smoke"
